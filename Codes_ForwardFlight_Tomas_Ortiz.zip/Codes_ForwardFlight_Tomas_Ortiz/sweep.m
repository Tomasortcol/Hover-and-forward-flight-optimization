%Function for obtaining the sweep angle of the leading edge after creating
%the blade implemeting the obtained chord distribution. The data is save in
%a .tex file that can be used with the code Analiza_Resultados_2sweep for
%checking the effect of the sweep angle.
%% CAD LOFT GUIDE GENERATOR CONSIDERING GEOM TWIST AND CHORD DISTRIBUTION
function [sweep_angle_rad]=sweep(Ttype,Ctype,xparam)
% Profile .DAT 

%%Airfoil data
data_profile = fopen('Save_Airfoil_N0012.txt');
data_profile_cell = textscan(data_profile, '%f %f');
data_mat=cell2mat(data_profile_cell); %coordenada X, Z profile
% figure(3)
% plot(data_mat(:,1),data_mat(:,2))
[val,index]=min(data_mat(:,1));

if data_mat(index,2)>=0
data_mat_upper=[data_mat(1:index,1), data_mat(1:index,2)];
data_mat_lower=[data_mat(index+1:end,1), data_mat(index+1:end,2)];
else
data_mat_upper=[data_mat(1:index-1,1), data_mat(1:index-1,2)];
data_mat_lower=[data_mat(index:end,1), data_mat(index:end,2)];
end

% Transformations so the X goes from zero to 
data_mat_upper=flip(data_mat_upper);
% Wing parameters

%%Rotor definition, chord and twist distributions
Span= 0.2; %m blade radius
r_hub= 0.02; %m hub radius
t_hub= 0.008; %m hub thickness

n=260;
dr = (1-0/Span)/n;                                                     %Radial increment - adimensional 
r = ((0/Span):dr:1);                                                   %preallocating the r-range


% Ttype=input('introduce the case of twist= ');
% Ctype= input('introduce the case of chord= ');
% xparam=input('introduce the case parameters= ');
[theta_col,c_root,slope,perc,percC,tap,param,param2]=GeomParam(Ttype,Ctype,xparam);
%Twist function//Chord function
[C,Twist]=distrib(Ttype,Ctype,theta_col,c_root,slope,perc,percC,tap,param,param2,r);

% Hub ellipse 

an = r_hub/2;
bn = 0.002/2;

center=[0.01,0];

ellipse_intrados_shape = @(x) - sqrt(bn^2 - (bn/an)^2*(x - center(1)).^2) + center(2);
ellipse_extrados_shape = @(x) sqrt(bn^2 - (bn/an)^2*(x - center(1)).^2) + center(2);

% Parameters for interpolation and guide

Nstations= 260;% Number of airfoils for creating the guide for the splines.
x_interp= (0: 0.005: 1);% number of panels that constitute the airfoil.
z_interp_upper=interp1([0;data_mat_upper(:,1)],[0;data_mat_upper(:,2)],x_interp); %lineal interpolation 
z_interp_lower=interp1([0;data_mat_lower(:,1)],[0;data_mat_lower(:,2)],x_interp);


for j=1:Nstations+1


dy = (1-0/Span)/Nstations;                                                      
y = ((0/Span):dy:1);                                                  

% Change of coordinates reference systems

ang=interp1(r,Twist,y(j))*180/pi;% angulo de rotacion en grados
chord= interp1(r,C,y(j));

% if j==1
%     chord=0.01;
% end

% % % for  keeping c/4 line cte
desp(j)=chord/4-interp1(r,C,y(1))/4;


%paso del sistema X,Z al X' Z'

%nos vamos al 25% de la cuerda de cada airfoil
x=chord*x_interp-(chord*0.25);
z_upper=z_interp_upper*chord;
z_lower=z_interp_lower*chord;

%Rotación del sistema x' z' al x'' z'' y se suma 0.25 para expresar de
%nuevo en X y Z

%se rota en el 25% y se vuelve al Le del airfoil
x_upper= cosd(ang)*x+sind(ang)*z_upper+(chord*0.25);
z_upper= -sind(ang)*x+cosd(ang)*z_upper;

x_lower= cosd(ang)*x+sind(ang)*z_lower+(chord*0.25);
z_lower= -sind(ang)*x+cosd(ang)*z_lower;


x_upper=x_upper-desp(j)-0.0095;
x_lower=x_lower-desp(j)-0.0095;

G_LE_1(j,1:3)=[-Span*y(j),x_upper(1),z_upper(1)];
G_TE_1(j,1:3)=[-Span*y(j),x_upper(end),z_upper(end)];

%signo - en el SPAN porque quiero que la helice gire en sentido horario
%Airfoil

Upper=[-Span*y(j)*ones(length(x_upper),1),x_upper',z_upper'];
Lower=[-Span*y(j)*ones(length(x_lower),1),x_lower',z_lower'];

Airf=[-Span*y(j)*ones(length(x_upper),1),x_upper',z_upper';...
      -Span*y(j)*ones(length(x_lower),1),flip(x_lower'),flip(z_lower')];


Airf=Airf*1000; %pasa a mm para Solid Works
Upper=Upper*1000;
Lower=Lower*1000;


% Define el radio de la circunferencia
radio = 0.018;
xcirc=linspace(0,radio,100);
zcirc=7e-3.*ones(length(xcirc));
% Genera puntos en la circunferencia
ycirc=+sqrt(radio^2-xcirc.^2);


end

CircSup=[+ycirc',xcirc',zcirc1';...
      -flip(ycirc(1:end-1))',flip(xcirc(1:end-1))',zcirc1(1:end-1)'].*1000;

CircSup2=[+ycirc',-xcirc',zcirc1';...
      -flip(ycirc(1:end-1))',flip(-xcirc(1:end-1))',zcirc1(1:end-1)'].*1000;

CircInf=[+ycirc',xcirc',zcirc2';...
     -flip(ycirc(1:end-1))',flip(xcirc(1:end-1))',zcirc2(1:end-1)'].*1000;

CircInf2=[+ycirc',-xcirc',zcirc2';...
     -flip(ycirc(1:end-1))',flip(-xcirc(1:end-1))',zcirc2(1:end-1)'].*1000;

G_LE_1=G_LE_1*1000; %pasa a mm para solidworks

G_TE_1=G_TE_1*1000; %pasa a mm para solidworks


%% Sweep Angle
% Calcular la derivada de G_LE con respecto a Y
G_LE_1=G_LE_1./1000;
dG_LE_dy = gradient(G_LE_1(:,2), Span*y);

% Calcular el ángulo de sweep en radianes
sweep_angle_rad = atan2(dG_LE_dy, 1);

% Convertir el ángulo de sweep a grados
sweep_angle_deg = rad2deg(sweep_angle_rad);

% Visualizar el ángulo de sweep en función de la posición a lo largo de la blade
% figure;
% plot(Span*y, sweep_angle_deg, 'LineWidth', 2);
% xlabel('Position along the blade (m)');
% ylabel('Sweep Angle (degrees)');
% title('Sweep Angle Distribution along the Blade');
% 
% % % Guardar el ángulo de sweep en un archivo de texto
% sweep_data = [Span*y', sweep_angle_deg];
% writematrix(sweep_data, 'Sweep_Angle_Data.txt', 'Delimiter', ',');
% % 
% % % Imprimir el ángulo de sweep promedio
% average_sweep_angle = mean(sweep_angle_deg);
% fprintf('Average Sweep Angle: %.2f degrees\n', average_sweep_angle);

end

function [c,theta_f]=distrib(Ttype,Ctype,theta_col,c_root,slope,perc,percC,tap,x,z,r)

  if Ctype==1
     indices = find(r <= percC(1));

     % Partir el vector en dos partes: a y b
     r1 = r(1:indices(end));
     r2 = r(indices(end)+1:end);

     c1 = c_root + (r1-r1(1))*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
     c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

     c=[c1,c2];
                       
                           
elseif Ctype==0

      c=c_tip*ones(1,length(r));

elseif Ctype==3
                            
      c = c_root + (r-r(1)).*(tap(1) - 1).*c_root./(r(end)-r(1));  

elseif Ctype==4
                            
      c = c_root + x.*(r-r(1)).^2-2.*x.*(r-r(1));                              


elseif Ctype==2

      P0=[r(1),c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

      Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

      Points=Bez(r'); 
      cx=Points(:,1); cy=Points(:,2);
      c=cy';

      end  
if Ttype==1
   indices = find(r <= perc(1));

% Partir el vector en dos partes: a y b
   r1 = r(1:indices(end));
   r2 = r(indices(end)+1:end);

   theta1 =theta_col +slope(1)*(r1-r1(1))./(r1(end)-r1(1)); %k2 and theta are in rads
   theta2=theta_col +slope(1)*(r1(end)-r1(1))./(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1));


   theta_f=[theta1,theta2];

elseif Ttype==5


   theta_f =theta_col +slope(1)*(r-r(1)); %k2 and theta are in rad

elseif Ttype==3

   indices = find(r <= perc1);
   indices2 = find(r > perc1 & r < perc2);

% Partir el vector en dos partes: a y b
   r1 = r(1:indices(end));
   r2=  r(indices(end)+1:inidices2(1)-1);
   r3 = r(indices2(1):indices2(end));         

   theta1 =theta_col +slope(1)*(r1-r1(1)); %k2 and theta are in rads
   theta2=theta_col+slope(1)*(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1));
   theta3=theta_col+slope(1)*(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1))+slope(3)*(r3-r3(1))./(r3(end)-r3(1));

   theta_f=[theta1,theta2,theta3];
 elseif Ttype==0
 
   theta_f=theta_col.*ones(1,length(r));      


 elseif Ttype==2
   
   Pt0=[r(1),z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

   Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

   Points2=Bez2(r'); 
   Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
   theta_f=Ty; %rad      
 elseif Ttype==6

   theta_f =theta_col +z(1).*(r).^2-2*z(1).*(r); %k2 and theta are in rad                            
                       
end      
    
end

function [theta_col,c_root,slope,perc,percC,tap,param,param2]=GeomParam(Ttype,Ctype,xparam)
    theta_col=10*pi/180;
    c_root=0.02;
           if Ttype==1 && Ctype==0

                theta_col=xparam(1); slope=xparam(2:3); perc=xparam(4); percC=[]; tap=[]; param=[]; param2=[];
  
        elseif Ttype==0 && Ctype==1

                    slope=[0 0]; perc=[]; c_root=xparam(1); percC=xparam(4); tap=xparam(2:3); param=[]; param2=[];
 
        elseif Ttype==1 && Ctype==1
                    
               theta_col=xparam(1); slope=xparam(2:3); perc=xparam(4); c_root=xparam(5); percC=xparam(8); tap=xparam(6:7); param=[]; param2=[];

        elseif Ttype==5 && Ctype==0
                    
                  theta_col=xparam(1);  slope=xparam(2); perc=[]; percC=[]; tap=[]; param=[]; param2=[];   

        elseif Ttype==5 && Ctype==3
                    
                  theta_col=xparam(1);  slope=xparam(2); perc=[]; c_root=xparam(3); percC=[]; tap=[xparam(4)]; param=[]; param2=[];                      

        elseif Ttype==0 && Ctype==3
                    
                    slope=[0 0]; perc=[]; percC=[]; c_root=xparam(1); tap=[xparam(2)]; param=[]; param2=[];                         
                
        elseif Ttype==0 && Ctype==2  
                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=xparam(1); param=xparam(2:end); param2=[];
                    
        elseif Ttype==1 && Ctype==2

                theta_col=xparam(1);    slope=xparam(2:3); perc=xparam(4); percC=[]; tap=[]; c_root=xparam(5); param=xparam(6:10); param2=[];

        elseif Ttype==2 && Ctype==2

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=xparam(7); param=xparam(8:12); param2=xparam(1:6);

        elseif Ttype==2 && Ctype==1

                    slope=[0 0]; perc=[]; percC=xparam(10); c_root=xparam(7); tap=xparam(8:9); param=[]; param2=xparam(1:6);
           
        elseif Ttype==2 && Ctype==0

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; param=[]; param2=xparam(1:6);

        elseif Ttype==6 && Ctype==0

               theta_col=xparam(1);     slope=[0 0]; perc=[]; percC=[]; tap=[];  param=[ ]; param2=[xparam(2)];   

        elseif Ttype==0 && Ctype==4

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=xparam(1); param=[xparam(2)]; param2=[];   

        elseif Ttype==6 && Ctype==2

                theta_col=xparam(1); slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=xparam(3); param=xparam(4:8); param2=xparam(2);

            end             
end