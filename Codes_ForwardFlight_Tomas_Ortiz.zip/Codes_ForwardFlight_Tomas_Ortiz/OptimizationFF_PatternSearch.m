%Optimization in Forward flight using PatternSearch, the option of using
%GlobalSearch is commented and can be used.
%The optimization is performed looking for the minimum power required for
%the rotor for providing the thrust required for the forward flight
%selected by the user (Variable Vf fixes the advance speed and consequently
%the inclination and drag of the model of drone). The code computes the
%rotational speed (Pilot input) at which the rotor should operate.
%The function Forward_flight_noflapping_RPM is using a modified lineal
%model for the inflow, the original inflow models can be activaded by
%uncommenting and following the isntructions inside that function.

%The initial variables :

% optimTwist=1;
% optimChord=1;
% Spline=1;
% Spline2=0;
% quad=1;
% 
% 
%  optim=1;

%are use for selecting the optimization case.

%optim=1 is required for activating the optimization.
%OptimTwist=1 activates the optimization of the twist. 0 desactivates the
%optimization of the twist and 5 activates the optimization of the twist
%for the lineal case.

%OptimChord=1 activates the optimization of the chord, 0 desactivates the
%optimization of the chord and 3 activates the case of tapered blade.

%The combination OptimTiwst=11 OptimChord=11 with all the rest 0 except for
%optim, activates the optimization of both chord and twist with 1 lineal
%segment distribution.

%The variables spline and spline2 can be 0 or 1. In case that optimization
%of twist or chord is desired with bézier distribution, spline =1 (for chord) or
%spline2=1 (for twist) is required within OptimTwist=1, OptimChord=1 or even both
%activated. 

%if OptimTiwst or OptimChord are 1 and quad=1 it activated the quad
%distribution.

%Tomás Ortiz
%% Acquisition of the informations about the Airfoil

clear all 
close all
clc

global  theta_col a_tpp CT_real rho dr d2r Nb f_drag A_eq CL_real CD_real r  R_min R_max c_root c_tip W lambda_climb muDim Aero 

optimTwist=1;
optimChord=1;
Spline=1;
Spline2=0;
quad=1;


 optim=1;
 Mod=5;


%% Input Data

n = 260;                                                                    %Number of radial stations to calculate
Nb = 2;                                                                     %Number of blades
c_tip = 0.02;                                                               %Blade Chord Length - tip - meters
c_root = 0.02;
theta_col=10*pi/180;                                                        %Blade pitch in case of no twist
W = 2.5;                                                                   %Mass of the vehicle in kg - needs to be multiplied for 9.807 
R_max = 0.2;                                                                  %Radius in meters
R_min = R_max*0.1;                                                               %Root cut-off in meters
h = 0;                                                                     %Altitude in meters
Vc = 0;                                                                     %Climb velocity - m/s
f_drag=1;
%% relacion Vf-atpp

nombreArchivo = sprintf('a_tpp_vs_Vf.txt');

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    a_tppExp = datos(:, 1);
    Vf_Exp = datos(:, 2);
    clear datos

    a_tppFun=polyfit(Vf_Exp,a_tppExp,2); %relacion cuadratica entre Vf y Drone Pitch




%% Preliminary Calculations

rho = 1.225*((288-0.0065*h)/288)^4.2561;                                    %Density kg/m^3
muDim=1.789*10^(-5);                                                        %Air Dynamic viscosity
dr = (1-R_min/R_max)/n;                                                     %Radial increment - adimensional 
r = ((R_min/R_max):dr:1);                                                   %preallocating the r-range


Ad = pi*((R_max)^2);                                                        %Disk Area - m^2
d2r = pi/180;                                                               %deg to radians


lambda_climb =0;% Vc/(rev*R_max);                                           %Adimensional inflow velocity for climb,
                                                                            %code is not implementing climbing, keep it 0
azimut = linspace(0,360,150);                                                           %azimut vector - step 1 deg
azimut = azimut*d2r;   
%% Aero Data

% Define el vector RE con 13 componentes
RE = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;

% Inicializa la estructura Aero
Aero = struct();

% Itera a través de los valores de RE
for i = 1:length(RE)
    % Genera el nombre del archivo utilizando sprintf
    nombreArchivo = sprintf('%d.txt', RE(i));

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    alpha = datos(:, 1);
    cl = datos(:, 2);
    cd = datos(:, 3);
            
    alpha=[-alpha(end:-1:1);alpha(2:end)];
    cl=[-cl(end:-1:1);cl(2:end)];
    cd=[cd(end:-1:1);cd(2:end)];

        % Crea vectores con NaN
    cl_grado = [datos(1, 4); NaN(size(alpha, 1) - 1, 1)];
    stall = [datos(1, 5); NaN(size(alpha, 1) - 1, 1)];
    cd_grado = [datos(1, 6); NaN(size(alpha, 1) - 1, 1)];

    % Concatena las columnas en una matriz y asigna a la estructura
    Aero.(['RE' num2str(i)]) = [alpha, cl, cd, cl_grado, stall, cd_grado];
end

[p_clalpha, p_cdalpha,ISAVE] = AeroProp;
[CL_real,CD_real]= AerData(p_clalpha,p_cdalpha);


%% Forward Flight - Input Data

Vf=10;                                                                    %Decide Vf, user input
a_tpp=polyval(a_tppFun,Vf);                                                %Drone AoA estimated from biblio data and Vf
a_tpp=a_tpp*pi/180;                                      
A_eq = 2*W*9.8*tan(a_tpp)/(1.225*Vf^2);                                    %equivalent area for parasite drag

%% Computations
if optim==0 % PARA RESOLVER CASOS SIN OPTIMIZAR 

Ttype=0; Ctype=0; perc=[0.6]; tap=[1]; percC=[]; slope=[-10]*pi/180; param=[ ]; param2=[];   %Here, the user must provide the geoemtry

[solution_matrix1(i,:),thetaf(i,:),alphaf(i,:),Chord(i,:),AER_rat(i,:)]= fsolve_RPM(Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,0.287541474604505,[]);       


% end     

elseif optim==1 

contador=1;
kprev=1;
for k=1:1

    fval=[];
    while isempty(fval)
    random = 0.2 + (0.9 - 0.2) * rand;
    random2 = 0.2 + (0.8- 0.2) * rand;
    random3 = 0.2 + (0.45 - 0.2) * rand;
    random4 = 0.55 + (0.8- 0.55) * rand;
    random5 = 0.35 + (0.75 - 0.35) * rand;
    random6 = -5 + (0+5) * rand;
    random7=5 + (25 - 5) * rand;
    random77=0 + (25 - 0) * rand;
    random777=-25 + (25 +25) * rand;
    random7777=-25 + (25+25) * rand;
    random8 = -10 + (0+10) * rand;
%     random9 = R_max*0.05 + (R_max.*0.1- R_max.*0.05) * rand;
%     random10 = R_max.*0.01 + (R_max.*0.1- R_max.*0.01) * rand;

%     random = 0.2 + (0.5 - 0.2) * rand;
%     random2 = 0.2 + (0.5- 0.2) * rand;
%     random3 = 0.1 + (0.3 - 0.1) * rand;
    random44 = 0.7 + (1.3- 0.7) * rand;
    random55 = 0.5 + (1/1.3 - 0.5) * rand;
%     random6 = 0.55 + (0.8- 0.55) * rand;
%     random7=5 + (25 -5) * rand;
%     random8 = 1 + (20- 1) * rand;
    random88 = -25 + (0+25) * rand;
    random888 = -25 + (0+25) * rand;
    random9 = R_max*0.05 + (R_max.*0.1- R_max.*0.05) * rand;
    random10 = R_max*0.01 + (R_max.*0.1- R_max.*0.01) * rand;
    random11 = R_max*0.01 + (R_max.*0.2- R_max.*0.01) * rand;
    random12 = R_max*0.01 + (R_max.*0.2- R_max.*0.01) * rand;


        if optimTwist==5 && optimChord==0 && Spline==0 && Spline2==0 && quad==0 %LinTwist / Cte Chord
                    %lineal twist, c cte
                    Ttype=5; Ctype=0;
                    %theta_col (root) , slope
                    x0 = [random7*pi/180 random88*pi/180]; 
                    LB = [5*pi/180 -25*pi/180];
                    UB = [25*pi/180 0*pi/180];    

        elseif optimTwist==11 && optimChord==11 && Spline==0 && Spline2==0 && quad==0 
                    %quadratic twist, cte chord
                    Ttype=5; Ctype=3;

                    x0 = [random7*pi/180  random88*pi/180 random9 random]; 
                    LB = [5*pi/180 -25*pi/180 R_max*0.05 0.2];
                    UB = [+25*pi/180 0*pi/180 R_max.*0.1 1];                      


        elseif optimTwist==0 && optimChord==3 && Spline==0 && Spline2==0 && quad==0 
                    % twist cte , lineal c

                    Ttype=0; Ctype=3;

                    x0 = [R_max*0.09 random]; 
                    LB = [R_max*0.05 0.2];
                    UB = [R_max.*0.1 1];    

        elseif optimTwist==0 && optimChord==1 && Spline==0 && Spline2==0 && quad==1 
                     % twist cte , quadratic c marco definition
                    Ttype=0; Ctype=4;

                    x0 = [random9 random10]; 
                    LB = [R_max*0.05 0];
                    UB = [R_max*0.1 R_max*0.1];                        

        elseif optimTwist==1 && optimChord==0 && Spline==0 && Spline2==0 && quad==1 
                    %quadratic twist, cte chord
                    Ttype=6; Ctype=0;

                    x0 = [random7*pi/180  random77*pi/180]; 
                    LB = [2*pi/180 0*pi/180];
                    UB = [+25*pi/180 +25*pi/180];   

                    


        elseif optimTwist==1 && optimChord==0 && Spline==0 && Spline2==0 && quad==0 
 
                     
                    Ttype=1; Ctype=0;
                     %theta_col, slope1,slope2, perc Change
                    x0 = [random7*pi/180  random88*pi/180 random888*pi/180 random]; 
                    LB = [5*pi/180 -25*pi/180 -25*pi/180 0.2];
                    UB = [25*pi/180 0*pi/180 0*pi/180 0.9];    

        elseif optimTwist==0 && optimChord==1 && Spline==0 && Spline2==0 && quad==0 

                    Ttype=0; Ctype=1;          
                         
                    x0 = [random9 0.8 0.8 random]; 
                    LB = [R_max.*0.05 0.5 0.3 0.2];
                    UB = [R_max.*0.1 1.3 1/1.3 0.8];    
        elseif optimTwist==1 && optimChord==1 && Spline==0 && Spline2==0 && quad==0% 2Lin Twist / 2Lin Chord
                    
                    Ttype=1; Ctype=1;
                    
                    x0 = [random7*pi/180 random88*pi/180 random888*pi/180 random random random9 random44 random55 random2]; 
                    LB = [5*pi/180 -25*pi/180 -25*pi/180 0.2 R_max*0.05 0.7 0.5 0.2];
                    UB = [25*pi/180 0*pi/180 0*pi/180 1 R_max*0.1 1.3 1/1.3 0.8];                    
        elseif optimTwist==1 && optimChord==1 && Spline==1 && Spline2==0 && quad==0 % 2Lin Twist / Bezier Chord
                    
                    Ttype=1; Ctype=2;
                    %theta, slope1 slope2, perc, croot, tapper ctip/croot, %coordenadas x e y de los puntos P1 y P2
                    x0 = [20*pi/180 -5*pi/180 -10*pi/180 random random9 0.5 random3 0.2*R_max random4 0.07*R_max]; 
                    LB = [0*pi/180 -20*pi/180 -20*pi/180 0.19 R_max*0.05 0.2 0.19 0.035*R_max 0.51 0.02*R_max];
                    UB = [40*pi/180 20*pi/180 20*pi/180 1 R_max*0.1 1 0.5 0.25*R_max 1 0.25*R_max];  
                     
        elseif optimTwist==0 && optimChord==1 && Spline==1 && Spline2==0 && quad==0 % CteTwist / Bezier Chord
                    
                    Ttype=0; Ctype=2;

                    %CROOT tapper ctip/croot, %coordenadas x e y de los puntos P1 y P2
                    x0 = [random9    0.3   random3    random11    random4    random12]; 
                    LB = [R_max*0.05 0.2 0.2 0.01*R_max 0.55 0.01*R_max];
                    UB = [R_max*0.1 1 0.45  0.2*R_max 0.8 0.2*R_max];  
        elseif optimTwist==1 && optimChord==0 && Spline==0 && Spline2==1 && quad==0 % Bezier Twist / Cte Chord
                    
                    Ttype=2; Ctype=0;
                    
                    
                    x0 = [random7*pi/180 random77*pi/180 random3 random777*pi/180 random4 random7777*pi/180]; 
                    LB = [5*pi/180 0*pi/180 0.2 -25*pi/180 0.55 -25*pi/180];
                    UB = [+25*pi/180 +25*pi/180 0.45 +25*pi/180 0.8 25*pi/180];  
                    

        elseif optimTwist==1 && optimChord==1 && Spline==1 && Spline2==1 && quad==0 % Bezier Twist / Bezier Chord
                    
                    Ttype=2; Ctype=2;
                    
                    x0 = [random7*pi/180 random77*pi/180 random3 random777*pi/180 random4 random7777*pi/180 random9    random    random3    random11    random4    random12]; 
                    LB = [5*pi/180 0*pi/180 0.2 -25*pi/180 0.55 -25*pi/180 R_max*0.05 0.2 0.2 0.03*R_max 0.55 0.03*R_max];
                    UB = [+25*pi/180 +25*pi/180 0.45 +25*pi/180 0.8 +25*pi/180 R_max*0.1 1 0.45 0.2*R_max 0.8 0.2*R_max];


        elseif optimTwist==1 && optimChord==1 && Spline==0 && Spline2==1 && quad==0 % Bezier Twist / 2lin Chord
                    
                    Ttype=2; Ctype=1;
                    
                    x0 = [random7*pi/180 random77*pi/180 random3 random777*pi/180 random4 random7777*pi/180 random9 random44 random55 random2]; 
                     LB = [5*pi/180 0*pi/180 0.2 -25*pi/180 0.55 -25*pi/180 R_max*0.05 0.7 0.5 0.2];
                     UB = [+25*pi/180 +25*pi/180 0.45 +25*pi/180 0.8 +25*pi/180 R_max*0.1 1.3 1/1.3 0.8];
        elseif optimTwist==1 && optimChord==1 && Spline==1 && Spline2==0 && quad==1 % Bezier Twist / 2lin Chord
                    
                    Ttype=6; Ctype=2;
                    
                    x0 = [random7*pi/180  random77*pi/180 random9 random random3 random11 random4 random12]; 
                    LB = [2*pi/180 0*pi/180 R_max*0.05 0.2 0.2 0.025*R_max 0.55 0.025*R_max];
                    UB = [+25*pi/180 +24*pi/180 R_max*0.1 1 0.45 0.2*R_max 0.8 0.2*R_max];                      
        end
objectivefunction = @(x) funtominimizeFF(x, Vf, Ttype, Ctype, Mod);
constraintfunction = @(x) fmc_constraintFFclean(x, Vf, Ttype, Ctype, Mod);


options = optimoptions(@patternsearch, 'Display', 'final');

[x(k, :), fval, exitflag, output] = patternsearch(objectivefunction,x0,[],[],[],[],LB,UB, ...
    constraintfunction,options);
   display(x(k,:)),
   display(fval),
   display(exitflag),


   %for running the problem using globalsearch
% gs = GlobalSearch;
% opts = optimoptions(@fmincon,'Algorithm','interior-point','Display','off');
% 
% problem = createOptimProblem('fmincon','x0',x0,'objective',objectivefunction,'nonlcon',constraintfunction,'lb',LB,'ub',UB,...
%                         'options',opts);
%                     
% [x(k,:),fval,exitflag] = run(gs,problem);




    end
    end                                  
for k=1:1
                    [~,solution_matrix(k,:)]=funtominimizeFF(x(k,:),Vf,Ttype,Ctype,Mod);
                    P_tot(k)=(solution_matrix(k,2)+solution_matrix(k,3)).*rho.*(pi*R_max^2).*(solution_matrix(k,1)*R_max)^3;%CPo+CPi
end
                    [min_CP, min_index] = min(P_tot);
                    Xsol=x(min_index,:);
                       
                    display(Xsol);
                    thetaCol=solution_matrix(1); CP_prof=solution_matrix(2);CP_ind=solution_matrix(3);
                    CP_tot=solution_matrix(4); CT_real=solution_matrix(5);





end


% end

function [p_clalpha, p_cdalpha,ISAVE] = AeroProp
global Aero
% Vector original

enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;

RE_estim=enteros_deseados;
% Redondear al entero más cercano
RE_redondeado = round(RE_estim);

% Lista de enteros deseada
RE=enteros_deseados;
% Ajustar los valores redondeados a los enteros deseados
for i = 1:length(RE_redondeado)
    valor_actual = RE_redondeado(i);
    diferencia = abs(enteros_deseados - valor_actual);
    [~, indice_min] = min(diferencia);
    RE_redondeado(i) = enteros_deseados(indice_min);
end

p_clalpha=0;p_cdalpha=0;

for k=1:length(RE_redondeado)

for i = 1:length(RE)
    condition = (RE_redondeado(k) == RE(i));
    if condition
        p_clalpha(k,1:Aero.(['RE' num2str(i)])(1,4)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,2), Aero.(['RE' num2str(i)])(1,4)).*(RE_redondeado(k)==RE(i));
        p_cdalpha(k,1:Aero.(['RE' num2str(i)])(1,6)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,3), Aero.(['RE' num2str(i)])(1,6)).*(RE_redondeado(k)==RE(i));
        ISAVE(k)=i.*(RE_redondeado(k)==RE(i));
   
    end

end
end



end


function [CL_real,CD_real]= AerData(p_clalpha,p_cdalpha)
global nRE Aero inicios_r fin_r CT_req lambda_climb
 enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;
 alpha_dato=linspace(-20,20,261);

   
                            for n=1:length(enteros_deseados)
                            alpha_datoCD= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+Aero.(['RE' num2str(n)])(1,5).*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato); %to avoid entering in stall
                            alpha_datoCL= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+7.*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato);                            
                            CL_real(:,n) = polyval(p_clalpha(n,1:Aero.(['RE' num2str(n)])(1,4)+1),alpha_datoCL(:));
                            CD_real(:,n) = polyval(p_cdalpha(n,1:Aero.(['RE' num2str(n)])(1,6)+1),alpha_datoCD(:));
%                             plot(alpha_dato,CL_real(:,n))
%                             hold on
                            end
                          
end 


function [solution_matrix1,thetaf,alphaf,Chord,AER_rat]= fsolve_RPM(Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col,revini)


revini=10000*pi/30; revant=revini;
% revsol=4000*pi/30;
global p T_req rho muDim slope_exp r p_clalpha p_cdalpha R_min R_max Nb f_drag A_eq c_root c_tip d2r dr dazimut W azimut lambda_climb Aero sub_r CL_real CD_real ISAVE
dazimut=azimut(2)-azimut(1);



%tollerance in deg for the calculation of the hovering condition CT
iteration = 20;                                                            %number of iteration for the convergence
toll_result =0.01;
step = 15;        
contatore=0;
error_cond=1;

while (abs(error_cond) > toll_result || step>5) && contatore < iteration
options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);
 
[revsol,fval,exitflag]=fsolve(@(rev) Forward_flight_without_flapping_drone_RPM(rev,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col),revini*1.15,options)

step=abs(revini-revsol).*30/pi;
revant=revsol;
error_cond=fval./T_req;
revini=revsol;

contatore=contatore+1;
end
[~,solution_matrix1,thetaf,alphaf,Chord,AER_rat]=Forward_flight_without_flapping_drone_RPM(revsol,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col);

end