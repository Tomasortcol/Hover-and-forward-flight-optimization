function [app_fmc,solution_matrix,thetaf,alphaf,Chord,AER_rat] = funtominimizeFF(x,Vf,Ttype,Ctype,Mod)
 global c_root theta_col rho R_max a_tpp
            if Ttype==1 && Ctype==0

                theta_col=x(1); slope=x(2:3); perc=x(4); percC=[]; tap=[]; param=[]; param2=[];
  
        elseif Ttype==0 && Ctype==1

                    slope=[0 0]; perc=[]; c_root=x(1); percC=x(4); tap=x(2:3); param=[]; param2=[];
 
        elseif Ttype==1 && Ctype==1
                    
               theta_col=x(1); slope=x(2:3); perc=x(4); c_root=x(5); percC=x(8); tap=x(6:7); param=[]; param2=[];

        elseif Ttype==5 && Ctype==0
                    
                  theta_col=x(1);  slope=x(2); perc=[]; percC=[]; tap=[]; param=[]; param2=[];   

        elseif Ttype==5 && Ctype==3
                    
                  theta_col=x(1);  slope=x(2); perc=[]; c_root=x(3); percC=[]; tap=[x(4)]; param=[]; param2=[];                      

        elseif Ttype==0 && Ctype==3
                    
                    slope=[0 0]; perc=[]; percC=[]; c_root=x(1); tap=[x(2)]; param=[]; param2=[];                         
                
        elseif Ttype==0 && Ctype==2  
                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=x(2:end); param2=[];
                    
        elseif Ttype==1 && Ctype==2

                theta_col=x(1);    slope=x(2:3); perc=x(4); percC=[]; tap=[]; c_root=x(5); param=x(6:10); param2=[];

        elseif Ttype==2 && Ctype==2

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(7); param=x(8:12); param2=x(1:6);

        elseif Ttype==2 && Ctype==1

                    slope=[0 0]; perc=[]; percC=x(10); c_root=x(7); tap=x(8:9); param=[]; param2=x(1:6);
           
        elseif Ttype==2 && Ctype==0

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; param=[]; param2=x(1:6);

        elseif Ttype==6 && Ctype==0

               theta_col=x(1);     slope=[0 0]; perc=[]; percC=[]; tap=[];  param=[ ]; param2=[x(2)];   

        elseif Ttype==0 && Ctype==4

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=[x(2)]; param2=[];   

        elseif Ttype==6 && Ctype==2

                theta_col=x(1); slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(3); param=x(4:8); param2=x(2);

            end             

        [solution_matrix,thetaf,alphaf,Chord,AER_rat]=fsolve_RPM(Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col,[]);
                    ratio=Vf*cos(a_tpp)/(solution_matrix(1,1).*0.2);
                    if ratio>=0.1
                    app_fmc = (solution_matrix(2)+solution_matrix(3)).*rho.*(pi*R_max^2).*(solution_matrix(1)*R_max)^3;
                    else
                    app_fmc = (solution_matrix(2)+solution_matrix(3)).*rho.*(pi*R_max^2).*(solution_matrix(1)*R_max)^3.*1/ratio;    
                    end
                    end


function [solution_matrix1,thetaf,alphaf,Chord,AER_rat]= fsolve_RPM(Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col,revini)


revini=10000*pi/30; revant=revini;
% revsol=4000*pi/30;
global  T_req dazimut azimut 
dazimut=azimut(2)-azimut(1);


%tollerance in deg for the calculation of the hovering condition CT
iteration = 20;                                                            %number of iteration for the convergence
toll_result =0.01;
step = 15;        
contatore=0;
error_cond=1;
exitflag=1;
if Ttype==5&&((theta_col-abs(slope(1))))<0
solution_matrix1=[2000	0.000237251468489614	0.000952300852475871	0.00244572716465200	0.00762592571989561	0.00125617484368652	0	0	0	1.75185587123430];
thetaf=[];alphaf=[];Chord=[];AER_rat=[];y=10.^-7;
elseif Ttype==1&&(((theta_col-abs(slope(1))-abs(slope(2))))<0||(theta_col-abs(slope(1)))<0)
    solution_matrix1=[2000	0.000237251468489614	0.000952300852475871	0.00244572716465200	0.00762592571989561	0.00125617484368652	0	0	0	1.75185587123430];
thetaf=[];alphaf=[];Chord=[];AER_rat=[];y=10.^-7;
elseif Ttype==6&&(theta_col<param2(1))
    solution_matrix1=[2000	0.000237251468489614*1.15	0.000952300852475871*1.15	0.00244572716465200	0.00762592571989561	0.00125617484368652	0	0	0	1.75185587123430];
thetaf=[];alphaf=[];Chord=[];AER_rat=[];y=10.^-7;
elseif Ttype==2
    [~,solution_matrix1,thetaf,alphaf,Chord,AER_rat]=Forward_flight_without_flapping_drone_RPM(revini,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col);

    if sum(thetaf<0)~=0
    solution_matrix1=[2000	0.000237251468489614	0.000952300852475871	0.00244572716465200	0.00762592571989561	0.00125617484368652	0	0	0	1.75185587123430];
    thetaf=[];alphaf=[];Chord=[];AER_rat=[];y=10.^-7;

    else 
        while (abs(error_cond) > toll_result || step>5) && contatore < iteration
        options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);
         
        [revsol,fval,exitflag]=fsolve(@(rev) Forward_flight_without_flapping_drone_RPM(rev,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col),revini*1.15*abs(exitflag),options);
        
        step=abs(revini-revsol).*30/pi;
        revant=abs(revsol);
        error_cond=fval./T_req;
        revini=abs(revsol);
        exitflag=exitflag*(exitflag~=0)+1.5*(exitflag==0);
        
        contatore=contatore+1;
        end
        [~,solution_matrix1,thetaf,alphaf,Chord,AER_rat]=Forward_flight_without_flapping_drone_RPM(revsol,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col);
       
    end


else
while (abs(error_cond) > toll_result || step>5) && contatore < iteration && Ttype~=2
options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);
 
[revsol,fval,exitflag]=fsolve(@(rev) Forward_flight_without_flapping_drone_RPM(rev,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col),revini*1.15*abs(exitflag),options);

step=abs(revini-revsol).*30/pi;
revant=abs(revsol);
error_cond=fval./T_req;
revini=abs(revsol);
exitflag=exitflag*(exitflag~=0)+1.5*(exitflag==0);

contatore=contatore+1;
end
[~,solution_matrix1,thetaf,alphaf,Chord,AER_rat]=Forward_flight_without_flapping_drone_RPM(revsol,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,param,param2,theta_col);
end
end