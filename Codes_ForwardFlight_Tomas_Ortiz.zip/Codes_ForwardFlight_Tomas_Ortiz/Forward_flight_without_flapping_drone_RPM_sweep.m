function [y,solution_matrix,thetaf,alphaf,Chord,AER_rat1]= Forward_flight_without_flapping_drone_RPM_sweep(rev,Vf,Ttype,Ctype,perc,percC,tap,slope,Mod,x,z,theta_col,sweepdist)
global  a_tpp T_req rho muDim  R_min R_max Nb f_drag A_eq c_root c_tip d2r dr dazimut W azimut lambda_climb r
dazimut=azimut(2)-azimut(1);


                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + (r1-r1(1))*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                       
                            %deg
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));

                            elseif Ctype==3
                            
                            c = c_root + (r-r(1)).*(tap(1) - 1).*c_root./(r(end)-r(1));  

                            elseif Ctype==4
                            
                            c = c_root.*(1 + x.*(r-r(1)).^2-2.*x.*(r-r(1)));                              


                            elseif Ctype==2

                            P0=[r(1),c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';

                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 
                            solidity_matrix = (solidity')*ones(1,length(azimut));
                            c_matrix=c'*ones(1,length(azimut));


mu=Vf./R_max./rev;

drag_ext = 0.5*rho*(Vf^2)*f_drag*A_eq;
    
                             





CP_parassite = (drag_ext*Vf)/(rho*A_eq*(rev*R_max)^3);                   %Parassite Power coefficient

options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);

T_req=(drag_ext.*sin(a_tpp)+W.*9.807.*cos(a_tpp))./4;

CT_req=T_req./(rho.*(rev*R_max)^2*(pi*R_max^2));

LambCini=sqrt(CT_req/2);

fun = @(lam_in) lam_in - CT_req/(2*sqrt((mu*cos(a_tpp))^2+(lam_in)^2));

lam=fsolve(@(lam_in) fun(lam_in),LambCini,options) ;


        %Linear Models

skew_angle = atan(mu*cos(a_tpp)/(lam + mu*sin(a_tpp))); %rad

[Kx,Ky]=inflow_mod(Mod,skew_angle,mu,lam,a_tpp);


% Old lineal model, uncomment for using Pitt and Peters or another

% lambda_PP = lam*(1+Kx*(r')*cos(azimut)+Ky*(r')*sin(azimut));

%   Modified lineal model for adapting to the observations in CFD, comment
%   next 4 lines if the original one wants to be used
Ky=Kx;
Kx=Kx -Kx.*0.2./(1+exp(-10.*(azimut-pi))); Ky= Ky -Ky.*0.15./(1+exp(-10.*(azimut-pi)));
lam= lam -lam.*0.3./(1+exp(-10.*(azimut-pi)));

lambda_PP = (1+(r')*Kx.*abs(cos(azimut))+(r')*Ky.*abs(sin(azimut))).*lam;

r_matrix = (r')*ones(1,length(azimut));

azimut_matrix = ones(length(r),1)*azimut;

ones_mat = ones(length(r),length(azimut));

sweepdist=sweepdist*ones(1,150);

Ut = (rev*r_matrix*R_max + Vf*sin(azimut_matrix)).*cos(abs(sweepdist));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Up = (lambda_climb*ones_mat+lambda_PP)*(rev*R_max);

phi = atan(Up./Ut); %inflow angle is cte

dim = size(r_matrix);
velocity_adim = (r_matrix+mu*ones(dim(1),1)*sin(azimut)).*cos(abs(sweepdist));


if Ttype==1
   indices = find(r <= perc(1));

% Partir el vector en dos partes: a y b
   r1 = r(1:indices(end));
   r2 = r(indices(end)+1:end);

   theta1 =theta_col +slope(1)*(r1-r1(1))./(r1(end)-r1(1)); %k2 and theta are in rads
   theta2=theta_col +slope(1)*(r1(end)-r1(1))./(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1));


   theta_f=[theta1,theta2];

elseif Ttype==5


   theta_f =theta_col +slope(1)*(r-r(1)); %k2 and theta are in rad

elseif Ttype==3

   indices = find(r <= perc1);
   indices2 = find(r > perc1 & r < perc2);

% Partir el vector en dos partes: a y b
   r1 = r(1:indices(end));
   r2=  r(indices(end)+1:inidices2(1)-1);
   r3 = r(indices2(1):indices2(end));         

   theta1 =theta_col +slope(1)*(r1-r1(1)); %k2 and theta are in rads
   theta2=theta_col+slope(1)*(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1));
   theta3=theta_col+slope(1)*(r1(end)-r1(1))+slope(2)*(r2-r2(1))./(r2(end)-r2(1))+slope(3)*(r3-r3(1))./(r3(end)-r3(1));

   theta_f=[theta1,theta2,theta3];
 elseif Ttype==0
 
   theta_f=theta_col.*ones(1,length(r));      


 elseif Ttype==2
   
   Pt0=[r(1),z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

   Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

   Points2=Bez2(r'); 
   Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
   theta_f=Ty; %rad      
 elseif Ttype==6

   theta_f =theta_col +z(1).*(r).^2-2*z(1).*(r); %k2 and theta are in rad    
                    
                       
end  

 % Calculo del RE
Vel=sqrt(Ut.^2+Up.^2);

RE_real=rho.*Vel.*c_matrix./muDim;
                        
theta_fvec=theta_f'*ones(1,length(azimut));

alpha_real =(theta_fvec - phi);%.*(Ut>=10)-0.72*pi/180.*(Ut<10));                   %alpha in radians // it is a matrix !!!
alpha_real =alpha_real/d2r;    %alpha in deg;
f = (Nb/2)*((1-r_matrix)./(r_matrix.*abs(phi)));
F = (2/pi)*acos(exp(-f));
f2 = (0.95/2)*((r_matrix-R_min/R_max)./(r_matrix.*abs(phi)));
F2 = (2/pi)*acos(exp(-f2));
 
[~,CL_interpolated,CD_interpolated,CT_real]=eq_solve(theta_col,alpha_real,velocity_adim,solidity_matrix,F,F2,RE_real,a_tpp,phi);

Coef=ones(dim(1),dim(2));

%for reverse flow
for k=1:dim(1)
    for l=1:dim(2)
            
        if r(k)<=-mu*sin(phi(k,l))&&-mu*sin(phi(k,l))>=0
           Coef(k,l) = -1;
        end               
     end
 end


  CP_profile = sum(sum(Coef.*0.5.*solidity_matrix.*CD_interpolated.*velocity_adim.^3*dr.*(dazimut/2/pi),2)); 
        %Drag



  CP_ind = sum(sum(lambda_PP.*0.5.*solidity_matrix.*CL_interpolated.*(velocity_adim.^2)*dr.*(dazimut/2/pi),2));
  CP_tot = CP_ind + CP_profile + CP_parassite;

  solution_matrix = [rev CP_ind CP_profile CP_tot CT_real CP_parassite,drag_ext.*sin(a_tpp)];

  thetaf=theta_f*180/pi;
  alphafmat=alpha_real;
  alphaf(1,:)=alphafmat(:,1);
  AER_rat=CL_interpolated./CD_interpolated;
  AER_rat1(1,:)=AER_rat(:,1);
  Chord=c;

%   H=(CT_real.*rho.*(rev*R_max)^2*(pi*R_max^2).*sin(a_tpp)-drag_ext)/cos(a_tpp);
  
  y=CT_real.*rho.*(rev*R_max)^2*(pi*R_max^2).*4-drag_ext.*sin(a_tpp)-W.*9.807.*cos(a_tpp);
 end



function [Kx,Ky]=inflow_mod(Mod,skew_angle,mu,lam,a_tpp)

        Kx = tan(skew_angle).*(Mod==1)+ ...
            4/3*(1-cos(skew_angle)-1.8*mu^2*cos(a_tpp)^2)/sin(skew_angle)*(Mod==2)+...
            4/3*mu*cos(a_tpp)/lam*(1.2+mu*cos(a_tpp)/lam).*(Mod==3)+...
            sqrt(2)*sin(skew_angle)*(Mod==4)+...
            (15*pi/23)*tan(skew_angle/2).*(Mod==5)+...
            sin(skew_angle)^2*(Mod==6);

        Ky=0-2*mu*cos(a_tpp)*(Mod==2);

end

function [y,CL_interpolated,CD_interpolated,CT_real,lambda,Caero,Coef,dCT_real]= eq_solve(theta_col,alpha_real,velocity_adim,solidity_matrix,F,F2,RE_real,a_tpp,phi)
global  CL_real CD_real  dazimut dr
 enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;
 alpha_dato=linspace(-20,20,261);

                            CL_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CL_real',alpha_real,RE_real,'spline');
                            CD_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CD_real',alpha_real,RE_real,'spline');
           
                            CT_profile = 0.5*solidity_matrix.*CD_interpolated.*velocity_adim.^2*dr;
                                                                             
                            CT_lift = 0.5.*solidity_matrix.*CL_interpolated.*(velocity_adim.^2)*dr;
                            CFz =CT_lift.*cos(phi)-CT_profile.*sin(phi);
                            CT_real=sum(sum(CFz,2).*(dazimut/2/pi));               
%          
                            y=0;

end 


