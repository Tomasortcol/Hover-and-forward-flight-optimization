% BEM theory FF

%This code serves for computing the forward flight power and pilot input
%required for the drone model selected at different advanced speeds and
%with different inclinations that depend on the advanced speed. The
%funciton Forward_flight_without_flapping_drone_RPM solves the forward
%flight problem using a modification of the lineal inflow models and
%without tip/hub losses. Original inflow models are implemented and they
%can be restores just by uncommenting a few lines in the code. The
%indications are provided inside the function, check the .mat file



%The code asks to the user for 4 inputs, the advance speed in m/s
%the type of twist distribution :
% 0 untwisted No parameters
%1 2.lin segment twist - provide theta_root slope1 slope2 and the
%percentage of the blade for changing the slope rperc
%2 Bézier twist distribution provide theta_root theta_tip and the
%coordinates of the control points, r1,theta1, t2, theta2 
%5 1 lin segment twist provide theta_root and the slope
%6 quadratic twist  provide theta_root and the parameter a, theta_root-a is
%the value of the pitch at the tip.

%the type of chord distribution :
% 0 straight no parameters
%1 2.lin segment chord chord at the root, tap ratio 1, tap ratio 2 and the
%percentage of the bldde for changing the slope
%2 Bézier chord distribution provide c_root tap ratio with the tip and the
%coordinates of the control points, r1,c1, t2, c2 
%5 1 lin segment chord provide c_root and the tap ratio
%4 quadratic chord c_root and a, with values between 0 and 1, if a=0
%staight blade, if 1, no chord at the tip.

%the patameters of the distributions are provide in row vector form x=[  ]
%put first the twist parameters and then the chord parameters

%possible combination of twist and chors 
%Ttype==1 && Ctype==0
% Ttype==0 && Ctype==1
% Ttype==1 && Ctype==1
% Ttype==5 && Ctype==0
% Ttype==5 && Ctype==3
% Ttype==0 && Ctype==3
% Ttype==0 && Ctype==2  
% Ttype==1 && Ctype==2
% Ttype==2 && Ctype==2
% Ttype==2 && Ctype==1
% Ttype==2 && Ctype==0
% Ttype==6 && Ctype==0
% Ttype==0 && Ctype==4
% Ttype==6 && Ctype==2

%Tomás Ortiz


%% Acquisition of the informations about the Airfoil

clear all %#ok<CLSCR>
% close all
clc

global  theta_col a_tpp rho dr d2r azimut Nb f_drag A_eq CL_real CD_real R_min R_max c_root c_tip W lambda_climb muDim Aero r

optimTwist=0 ;
optimChord=0 ;
Spline=0;
Spline2=0;
quad=0;


 optim=1;
 Mod=5;


%% Input Data

n = 260;                                                                    %Number of radial stations to calculate
Nb = 2;                                                                     %Number of blades
c_tip = 0.02;                                                               %Blade Chord Length - tip - meters
c_root = 0.02;
theta_col=10*pi/180;
% RPM = 257.831;                                                                 %Rev / Min
W = 2.5;                                                                   %Mass of the helicopter in kg - needs to be multiplied for 9.807 
R_max = 0.2;                                                                  %Radius in meters
R_min = R_max*0.1;                                                               %Root cut-off in meters
h = 0;                                                                   %Altitude in meters
Vc = 0;                                                                     %Climb velocity - m/s
f_drag = 1;
% A_eq = 0.009;                   





%% relacion Vf-atpp

nombreArchivo = sprintf('a_tpp_vs_Vf.txt');

    %reed the file nombreArchivo
    contenido = fileread(nombreArchivo);

    %Erase tabs in the .tex file
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Save the content from the file
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Read the data
    datos = importdata(nombreTemporal, '\t');

    %Erase the file
    delete(nombreTemporal);

    % Export the data in vectors
    a_tppExp = datos(:, 1);
    Vf_Exp = datos(:, 2);
    clear datos

    a_tppFun=polyfit(Vf_Exp,a_tppExp,2); %relacion cuadratica entre Vf y Drone Pitch




%% Preliminary Calculations

rho = 1.225*((288-0.0065*h)/288)^4.2561;                                          %Density kg/m^3
muDim=1.789*10^(-5);
% rev = RPM*(2*pi)/60;                                                        %Radians per second
dr = (1-R_min/R_max)/n;                                                     %Radial increment - adimensional 
r = ((R_min/R_max):dr:1);                                                   %preallocating the r-range


Ad = pi*((R_max)^2);                                                        %Disk Area - m^2
d2r = pi/180;                                                               %deg to radians

% T_req = (W*9.807)./4;                                  %Thrust coefficient requested in hovering for this helicopter
lambda_climb =0;% Vc/(rev*R_max);                                              %Adimensional inflow velocity for climb

%% Aero Data

% Define el vector RE con 13 componentes
RE = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;

% Initialize the structure Aero, where the aerodynamic airfoil data will be
% save
Aero = struct();

for i = 1:length(RE)
   
    nombreArchivo = sprintf('%d.txt', RE(i));

    
    contenido = fileread(nombreArchivo);

    
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    
    datos = importdata(nombreTemporal, '\t');

    
    delete(nombreTemporal);

    
    alpha = datos(:, 1);
    cl = datos(:, 2);
    cd = datos(:, 3);
            
    alpha=[-alpha(end:-1:1);alpha(2:end)];
    cl=[-cl(end:-1:1);cl(2:end)];
    cd=[cd(end:-1:1);cd(2:end)];

        
    cl_grado = [datos(1, 4); NaN(size(alpha, 1) - 1, 1)];
    stall = [datos(1, 5); NaN(size(alpha, 1) - 1, 1)];
    cd_grado = [datos(1, 6); NaN(size(alpha, 1) - 1, 1)];

    
    Aero.(['RE' num2str(i)]) = [alpha, cl, cd, cl_grado, stall, cd_grado];
end

[p_clalpha, p_cdalpha,ISAVE] = AeroProp;
[CL_real,CD_real]= AerData(p_clalpha,p_cdalpha);
%% Parameters for the convergence and the parametric analysis

toll = 0.0025;                                                              %tollerance in deg for the calculation of the hovering condition CT
iteration = 5000;                                                            %number of iteration for the convergence

toll_result = 0.0005;


%% Forward Flight - Input Data
Vf_vec =linspace(0.1,20,20); 

    azimut = linspace(0,360,150);                                                           %azimut vector - step 1 deg
    azimut = azimut*d2r;   



Vf_vec2=input('Introduce type of Forward speed= ');
Ttype=input('Introduce type of Twist= ');
Ctype=input('Introduce type of Chord= ');

x=input('introduce geometrycal parameters= ');


%% Optim






for k=1:length(x(:,1))
    Vf=Vf_vec2(k);

a_tpp=polyval(a_tppFun,Vf);
a_tpp=a_tpp*pi/180;
A_eq = 2*W*9.8*tan(a_tpp)/(1.225*Vf^2);  

contador=1;
kprev=1;

                    [~,solution_matrix(k,:),thetaf(k,:),alphaf(k,:),Chord(k,:),AER_rat(k,:)]=funtominimizeFF(x(k,:),Vf,Ttype,Ctype,Mod);
                    P_tot(k)=(solution_matrix(k,2)+solution_matrix(k,3)).*rho.*(pi*R_max^2).*(solution_matrix(k,1)*R_max)^3;%CPo+CPi
                    Tgen(k)=solution_matrix(k,5).*rho.*(pi*R_max^2).*(solution_matrix(k,1)*R_max)^2;
                    figure(1)
                    plot(r,thetaf(k,:),'LineWidth',2)
                    ratio(k)=Vf.*cos(a_tpp)/(solution_matrix(k,1).*0.2);

                   xlabel('r'), ylabel('pitch (\theta) (deg)'), legend('10m/s','15m/s','20m/s','Location','best')
                    hold on
                     figure(2)
                    plot(r,Chord(k,:),'LineWidth',2)
                    xlabel('r'), ylabel('Chord(m)'), legend('10m/s','15m/s','20m/s','Location','best')
                    hold on

end
                    [min_CP, min_index] = min(P_tot);
                    Xsol=x(min_index,:);
                    Psol=min(P_tot); 

                    display(min_index);
                    display(Xsol);
                    display(Psol);
           







% end

function [p_clalpha, p_cdalpha,ISAVE] = AeroProp
global Aero
% Vector original

enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;

RE_estim=enteros_deseados;
% Redondear al entero más cercano
RE_redondeado = round(RE_estim);

% Lista de enteros deseada
RE=enteros_deseados;
% Ajustar los valores redondeados a los enteros deseados
for i = 1:length(RE_redondeado)
    valor_actual = RE_redondeado(i);
    diferencia = abs(enteros_deseados - valor_actual);
    [~, indice_min] = min(diferencia);
    RE_redondeado(i) = enteros_deseados(indice_min);
end

p_clalpha=0;p_cdalpha=0;

for k=1:length(RE_redondeado)

for i = 1:length(RE)
    condition = (RE_redondeado(k) == RE(i));
    if condition
        p_clalpha(k,1:Aero.(['RE' num2str(i)])(1,4)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,2), Aero.(['RE' num2str(i)])(1,4)).*(RE_redondeado(k)==RE(i));
        p_cdalpha(k,1:Aero.(['RE' num2str(i)])(1,6)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,3), Aero.(['RE' num2str(i)])(1,6)).*(RE_redondeado(k)==RE(i));
        ISAVE(k)=i.*(RE_redondeado(k)==RE(i));
   
    end

end
end



end


function [CL_real,CD_real]= AerData(p_clalpha,p_cdalpha)
global nRE Aero inicios_r fin_r CT_req lambda_climb
 enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000 12000] * 1000;
 alpha_dato=linspace(-20,20,261);

   
                            for n=1:length(enteros_deseados)
                            alpha_datoCD= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+Aero.(['RE' num2str(n)])(1,5).*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato); %to avoid entering in stall
                            alpha_datoCL= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+5.*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato);                            
                            CL_real(:,n) = polyval(p_clalpha(n,1:Aero.(['RE' num2str(n)])(1,4)+1),alpha_datoCL(:));
                            CD_real(:,n) = polyval(p_cdalpha(n,1:Aero.(['RE' num2str(n)])(1,6)+1),alpha_datoCD(:));

                            end
                          
end 

