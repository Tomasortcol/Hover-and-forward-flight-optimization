function [solution_matrix,thetah,alphah,Chord,AER_rat]= Hover_Drone2(Ttype,Ctype,perc,percC,tap,slope,x,z,ini,flag)



global   CT_req slope_exp r R_min R_max Nb c_root c_tip d2r dr lambda_climb rho muDim nRE inicios_r fin_r Aero rev sub_r CL_real CD_real ISAVE

PenaltyC=0; PenaltyL=0; kappa0=100 ; kappa1=1 ; kappa2= 1; lim_sup=c_root*1.5; lim_inf=0.1*c_root; lim_sup2=25*pi/180; lim_inf2=-25*pi/180;

                                                           %tollerance in deg for the calculation of the hovering condition CT
iteration = 40;                                                            %number of iteration for the convergence
toll_result = 0.04;
step = 0.20;        
contatore=0;
error_cond=1;

                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + r1*(tap(1) - 1)*c_root;                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                       
                            %deg
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));

                            elseif Ctype==2

                            P0=[0,c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';
                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 

                            F=1;
                            F2=1;
%                             k2ini=6*CT_req./(solidity(183).*slope_exp)+3/2*sqrt(CT_req/2);
                            if isempty(ini)
                            k2ini=5*pi/180;
                            else
%                             k2ini=0.6*(CT_req>0.003)*(CT_req<=0.015)*(flag~=1)+0.8*(CT_req>0.017)+ini*(flag==1)+0.2*(CT_req<=0.003)*(flag~=1);
                            k2ini=ini;
                            end
                            lambda=@(k2) sqrt(CT_req/2);                            
while (abs(error_cond) > toll_result || step>0.2) && contatore < iteration 
                            
                            dim_r = size(r);
                            theta_hov = zeros(dim_r(1),dim_r(2));

                       if Ttype==1
                            indices = find(r <= perc(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            theta1 =@(k2) k2 +slope(1)*r1; %k2 and theta are in rads
                            theta2=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2-r2(1))./(r2(end)-r2(1));


                            theta_hov=@(k2) [theta1(k2),theta2(k2)];
                            %deg
                        elseif Ttype==3

                            indices = find(r <= perc1);
                            indices2 = find(r > perc1 & r < perc2);

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2=  r(indices(end)+1:inidices2(1)-1);
                            r3 = r(indices2(1):indices2(end));         

                            theta1 =@(k2) k2 +slope(1)*r1; %k2 and theta are in rads
                            theta2=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2-r2(1));
                            theta3=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2(end)-r2(1))+slope(3)*(r3-r3(1));

                            theta_hov=@(k2) [theta1(k2),theta2(k2),theta3(k2)];

                        elseif Ttype==0
 
                            theta_hov=@(k2) k2.*ones(1,length(r)); 

                        elseif Ttype==2
   
                            Pt0=[0,z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

                            Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

                            Points2=Bez2(r'); 
                            Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
                            theta_hov=@(k2) Ty+k2; %rad 
                            
                       elseif Ttype==4
   
                            theta_hov=@(k2)k2./r; %rad %ideal rotor solution, it is hyperbolic

                       elseif Ttype==5


                            theta_hov =@(k2) k2 +slope.*r; %k2 and theta are in rad                            
             

                       elseif Ttype==6


                            theta_hov =@(k2) k2 +x(1).*r.^2-2*x(1).*r; %k2 and theta are in rad                            
                            
                        end                       
   
  
                        
                            if contatore>0&&Ttype~=4
                                F(end)=+0.01;  %to avoid dividing by 0 in the expression of Lambda
                            elseif Ttype==4
                                F=1; F2=1;
                            end

                            if contatore>0 && isreal(lambda(k2sol))==0

                                
                                k2ini=0.3;
                                F=1; F2=1;
                            end

                            F=F.*ones(1,length(r));


                            % Calculo del RE
                            Vel=sqrt((rev*r*R_max).^2+(lambda(k2ini).*(rev.*R_max)).^2);
%                             inicio=1; fin=length(sub_r{1,1});

                            for n=1:nRE
                            c_RE(n)=mean(c(inicios_r{1,n}:fin_r{1,n}));
                            Vel_avg(n)=mean(Vel(inicios_r{1,n}:fin_r{1,n}));
                            end
                            RE_real=rho.*Vel.*c./muDim;
                            RE_vec=rho.*Vel_avg.*c_RE./muDim;

                            
                            lambda = @(k2) ((solidity.*slope_exp)./(16.*F)).*(sqrt(1+((32.*F)./(solidity.*slope_exp)).*theta_hov(k2).*r)-1).*(theta_hov(k2)>=0)+0.0001.*(theta_hov(k2)<0);
                            alpha_real =@(k2) theta_hov(k2) - lambda(k2)./r;                               %alpha in radians
                            alpha_real =@(k2) alpha_real(k2)/d2r;                                    %alpha in deg

                            options = optimoptions('fsolve','Display','off','StepTolerance',1e-3,'MaxFunEvals',1e8,'MaxIter',200);
                                
                            [k2sol,fval,exitflag]=fsolve(@(k2) eq_solve(k2,alpha_real,r,dr,solidity,F,F2,RE_real),k2ini,options)
                            imagine=imag(k2sol);
                            k2sol=real(k2sol);
                            if Ttype~=4
                            f = (Nb/2)*((1-r)./lambda(k2sol));
                            F = (2/pi)*acos(exp(-f));
                            f2 = (0.95/2)*((r-R_min/R_max)./lambda(k2sol));
                            F2 = (2/pi)*acos(exp(-f2));
                            end
                            fval=fval./(rho.*(rev*R_max)^2*(pi*R_max^2));
                            error_cond = fval/CT_req;
                            step=abs(k2ini-k2sol)*180/pi;
                            k2ini=k2sol;
                            
                   

                            contatore = contatore + 1;


end

[~,CL_interpolated,CD_interpolated,CT_real]=eq_solve(k2sol,alpha_real,r,dr,solidity,F,F2,RE_real);

PenaltyCont=0;

               if  (contatore==iteration) || imagine~=0
%                    fprintf('Error in the convergence, %.2f %.4f %.4f \n', tap,k2sol,slope);
                   PenaltyCont=abs(error_cond)*100;
                   PenaltyL=kappa0*(abs(imagine)).^2;
                   
               end
                    %Calcolo CP indotta per questa condizione

                    PenaltyCvec= kappa1.*max(0,c-lim_sup).^2+kappa2.*(max(0,lim_inf-c)).^2;

                    PenaltyTvec= kappa1.*max(0,theta_hov(k2sol)-lim_sup2).^2+kappa2.*(max(0,lim_inf2-theta_hov(k2sol))).^2;

                    CP_ind = sum(lambda(k2sol).*0.5.*solidity.*CL_interpolated.*(r.^2).*dr);

                    %Profile drag

                    CP_profile = sum(0.5*solidity.*CD_interpolated.*(r.^3)*dr);
                    

                    %Drag

                    CP_tot = CP_ind + CP_profile;

                    PenaltyC= sum(PenaltyCvec)*(sum(PenaltyCvec<=CP_tot))+CP_tot*(sum(PenaltyCvec)>2*CP_tot); 

                    PenaltyT= (sum(PenaltyTvec)*(sum(PenaltyTvec<=CP_tot))+CP_tot*(sum(PenaltyTvec)>2*CP_tot))*(Ttype~=4); 


                    % riempimento matrice soluzione

                    solution_matrix = [k2sol CP_ind CP_profile CP_tot CT_real,PenaltyC,PenaltyL, PenaltyT,PenaltyCont,error_cond,exitflag]
                    thetah=theta_hov(k2sol)*180/pi;
                    alphah=alpha_real(k2sol);
                    Chord=c;
                    AER_rat=CL_interpolated./CD_interpolated;
                                

k2sol*180/pi
end

function [y,CL_interpolated,CD_interpolated,CT_real]= eq_solve(x,alpha_real,r,dr,solidity,F,F2,RE_real)
global CT_req CL_real CD_real rho rev R_max
 enteros_deseados = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;
 alpha_dato=linspace(-20,20,261);

  
                           
                            CL_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CL_real',alpha_real(x),RE_real,'spline');
                            CD_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CD_real',alpha_real(x),RE_real,'spline');

                            CT_real = sum(0.5*solidity.*CL_interpolated.*(r.^2)*dr);

                            y=(CT_real-CT_req).*rho.*(rev*R_max)^2*(pi*R_max^2);

end 
