function [solution_matrix,thetah,alphah,Chord,AER_rat]= HoverNoLin(Ttype,Ctype,perc,percC,tap,slope,x,z,k2ini)



global  CT_req r p_clalpha p_cdalpha R_min R_max Nb c_root c_tip d2r dr lambda_climb


                                                           %tollerance in deg for the calculation of the hovering condition CT
iteration = 200;                                                            %number of iteration for the convergence
toll_result = 0.01;
step = 0.20;        
contatore=0;
error_cond=1;

                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + r1*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));

                            elseif Ctype==2

                            P0=[0,c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';

                            elseif Ctype==4
                            
                            c = c_root.(1 + x.*(r-r(1)).^2-2.*x.*(r-r(1)));    

                                                            
                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 

                            F=1;
                            F2=1;
%                             k2ini=6*CT_req./(solidity(183).*slope_exp)+3/2*sqrt(CT_req/2)*1.15;
                            lambda=@(k2) sqrt(CT_req/2);
                            phi_ini=atan(lambda(k2ini)./r);
                            

while (abs(error_cond) > toll_result || step>1 || step2>1 || contatore<2) && contatore < iteration
                            
                            dim_r = size(r);
                            theta_hov = zeros(dim_r(1),dim_r(2));

                       if Ttype==1
                            indices = find(r <= perc(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            theta1 =@(k2) k2 +slope(1)*r1; %k2 and theta are in rads
                            theta2=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2-r2(1));


                            theta_hov=@(k2) [theta1(k2),theta2(k2)];
                            %deg

                        elseif Ttype==0
 
                            theta_hov=@(k2) k2.*ones(1,length(r)); 

                        elseif Ttype==2
   
                            Pt0=[0,z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

                            Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

                            Points2=Bez2(r'); 
                            Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
                            theta_hov=@(k2) Ty+k2; %rad 
                            
                       elseif Ttype==4
   
                            theta_hov=@(k2)k2./r; %rad %ideal rotor solution, it is hyperbolic

                       elseif Ttype==5


                            theta_hov =@(k2) k2 +slope.*r; %k2 and theta are in rad                            
             

                       elseif Ttype==6


                            theta_hov =@(k2) k2 +x(1).*r.^2-2*x(1).*r; %k2 and theta are in rad                            
                            
                        end                       
   
  
                            
                            if contatore>0&&Ttype~=4
                                F(end)=F(end)+10^-3;  %to avoid dividing by 0 in the expression of Lambda

                            elseif Ttype==4
                                F=1; F2=1; 
                            end

                            if contatore>0 && isreal(lambda(k2sol))==0

                                
                                k2ini=0.4;
                                F=1; F2=1;
                       
                            end

                            F=F.*ones(1,length(r));
                            
                            alpha_real =@(k2,phi) theta_hov(k2) - phi;                             %alpha in radians
                            alpha_real =@(k2,phi) alpha_real(k2,phi)/d2r;                                    %alpha in deg
                            alpha_real2CD=@(k2,phi)alpha_real(k2,phi).*(abs(alpha_real(k2,phi))<=18)+18.*(abs(alpha_real(k2,phi))>18).*sign(alpha_real(k2,phi)); %to avoid entering in stall
                            alpha_real2CL=@(k2,phi)alpha_real(k2,phi).*(abs(alpha_real(k2,phi))<=18)+5.*(abs(alpha_real(k2,phi))>18).*sign(alpha_real(k2,phi));
                            CL_real =@(k2,phi) polyval(p_clalpha,alpha_real2CL(k2,phi));                            
                            CD_real =@(k2,phi) polyval(p_cdalpha,alpha_real2CD(k2,phi));
                            Caero=@(k2,phi)CL_real(k2,phi).*cos(phi)-CD_real(k2,phi).*sin(phi);
                            Coef=@(k2,phi)1/8.*solidity.*Caero(k2,phi)./r./[F(1:end-1),F(end-1)];


                            lambda = @(k2) (lambda_climb+sqrt(lambda_climb.^2+4.*(1-Coef(k2,phi_ini)).*Coef(k2,phi_ini).*sign(Coef(k2,phi_ini)).*r.^2))./(2.*(1-Coef(k2,phi_ini))).*(Coef(k2,phi_ini)>=0)+0.0001.*(Coef(k2,phi_ini)<0);

                            CT_real = @(k2) sum(0.5*solidity.*F2.*Caero(k2,phi_ini).*(r.^2)*dr);                          
                            ec=@(k2) CT_real(k2)-CT_req;

                            options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);

                                
                            k2sol=fsolve(@(k2) ec(k2),k2ini,options)
                            imagine=imag(k2sol);
                            k2sol=real(k2sol);
                            
                            if Ttype~=4
                            phi_ant=phi_ini;
                            phi_ini=atan(lambda(k2sol)./r);
                            phi_ini=[phi_ini(1:end-1),phi_ini(end-1)];
                            f = (Nb/2)*((1-r)./abs(lambda(k2sol)));
                            F = (2/pi)*acos(exp(-f));
                            f2 = (0.95/2)*((r-R_min/R_max)./abs(lambda(k2sol)));
                            F2 = (2/pi)*acos(exp(-f2));
                            
                            end

                            error_cond = (CT_real(k2sol) - CT_req)/CT_req;
                            step=abs(k2ini-k2sol)*180/pi;
                            step2=abs(phi_ini(182)-phi_ant(182))*180/pi;
                            k2ini=k2sol;

                   

                            contatore = contatore + 1;

end

               if  (contatore==iteration) || imagine~=0
                   fprintf('Error in the convergence');
                   
                   
               end
                    %Calcolo CP indotta per questa condizione
                    

                    %First CP_ind is obtained assuming that vi<<Vtip(Omera.*R)
%                     CP_ind = sum(0.5.*solidity.*CL_real(k2sol,phi_ant).*sin(phi_ant).*(r.^3).*dr); 
                    CP_ind = sum(0.5.*solidity.*CL_real(k2sol,phi_ant).*sin(phi_ant).*(r.^3+lambda(k2sol).^2.*r).*dr);

                    %Profile drag
                     %First CP_profile is obtained assuming that vi<<Vtip(Omera.*R)
%                     CP_profile = sum(0.5*solidity.*CD_real(k2sol,phi_ant).*cos(phi_ant).*(r.^3).*dr);
                    CP_profile = sum(0.5*solidity.*CD_real(k2sol,phi_ant).*cos(phi_ant).*(r.^3+lambda(k2sol).^2.*r).*dr);

                    %Drag

                    CP_tot = CP_ind + CP_profile+CP_ind*(contatore==iteration)


                    % riempimento matrice soluzione

                    solution_matrix = [k2sol CP_ind CP_profile CP_tot CT_real(k2sol)];
                    thetah=theta_hov(k2sol)*180/pi;
                    alphah=alpha_real2CD(k2sol,phi_ant);
                    Chord=c;
                    AER_rat=CL_real(k2sol,phi_ant)./CD_real(k2sol,phi_ant);
                                

end
