% BEM theory for hovering 
% Tomás Ortiz

%This code computes the thrust and the power generated and required for a
%rotor in hover flight. The code requires the full geometry of the rotor.
%Additionally, it compares againts experimental data of C.Vasconcelos.
%The function Hover_Drone2_NoSole2 does not compute any pilot input (neither collective pitch nor rotational speed )
%There are multiple combinations of possible twist and chord distributions,
%which are selected by means of the variables Ctype and Ttype.

%Combinations of chord and twist.

%Ctype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables c_root, tap and percC.

%Ctype=0 Straight blade defined by the value of c_tip

%Ctype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param=[tap, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the taper ratio between c_root and c_tip desired and the
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. c_P1 and c_P2 are the
%''chord'' position of those controls points, depending on their value the
%chord will grow more or less (they can be negative but carefully because it can lead to negative chords in the distribution which is unrealistic.)

%Ctype=4 Quadratic chord distribution, c_root and param=[a] shall be provided by the user. a is a value between 0,1  
%if a=0 the distribution will be a straig blade. if a=1 the chord at the
%tip will be 0. Since the apex of the parabola is in the tip, it defines
%the chord at the tip.

%Ttype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables twistAng (which is the collective pitch), slope vector, which contains
% the twis increments of twist in each segment and perc=[rperc1] variable
% with the percentage of the blade for changing the twist rate


%Ttype=0 Untwisted blade with constant pitch defined by TwistAngle.

%Ttype=5 Lineal twist, provide TwistAng and slope, which is the differential pitch between tip and chord.

%Ttype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param2=[theta_root, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the pitch at the root, theta_root.
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. theta_P1 and theta_P2 are the
%''pitch'' position of those controls points, depending on their value the
%pitch will grow more or less (it can be either positive or negative but be carefully with providin unrealistic distributions)

%Ttype=6 Quadratic twist distribution, c_root and param=[a] shall be provided by the user  
% Since the apex of the parabola is in the tip, it defines
%the twist at the tip.

%% Acquisition of the informations about the Airfoil

clear all
close all
clc

global   dr d2r solidity Nb  CL_real CD_real ISAVE slope_exp r p_clalpha p_cdalpha...
        R_min R_max c_root c_tip lambda_climb rho muDim nRE inicios_r fin_r Aero rev sub_r  mean_slope  CLo%CL CD alpha
                                                 

%% Input Data

nRE = 260;                                                                    %Number of radial stations to calculate
Nb = 2;                                                                     %Number of blades
c_tip = 0.018;                                                               %Blade Chord Length - tip - meters
c_root =   0.018;
RPM_vec = (3000:500:6000);                                                                 %RPM                                                  
W = 0.2;                                                                   %Mass of the helicopter in kg - needs to be multiplied for 9.807 
R_max =  0.10;                                                                  %Radius in meters
R_min = 0.01;                                                               %Root cut-off in meters
%  R_min = 0.1*R_max; 
h = 0;                                                                     %Altitude in meters
Vc = 0;


%% Preliminary Calculations

rho = 1.225*((288-0.0065*h)/288)^4.2561;                                          %Density kg/m^3
muDim=1.789*10^(-5);
% rev = RPM.*(2*pi)/60;                                                        %Radians per second
dr = (1-R_min/R_max)/nRE;                                                     %Radial increment - adimensional 
r = ((R_min/R_max):dr:1);                                                   %preallocating the r-range
slope_exp=6.41;



%% CL and CD data base. Linearization of the polars with XFOIL.

nRE = 10; 

% Calcula la longitud de cada subvector
longitud_total = numel(r);
longitud_subvector = floor(longitud_total / nRE);

% Inicializa una celda para almacenar los subvectores
subvectores = cell(1, nRE);

% Divide el vector en subvectores de igual longitud
inicio = 1;
% sub_i=zeros(nRE,50);
for i = 1:nRE
    if i <= mod(longitud_total, nRE)
        fin = inicio + longitud_subvector;
    else
        fin = inicio + longitud_subvector - 1;
    end
    sub_r(i,1:fin-inicio+1) = r(inicio:fin);
    inicios_r{i}=inicio;
    fin_r{i}=fin;
    inicio = fin + 1;
end
% 
% [~,~,mean_slope,~,CLo]=prueba_slopes;

% % %% Aero Data
% % % Define el vector RE con 13 componentes
RE = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;

% Inicializa la estructura Aero
Aero = struct();

% Itera a través de los valores de RE
for i = 1:length(RE)
    % Genera el nombre del archivo utilizando sprintf
    nombreArchivo = sprintf('%d.txt', RE(i));

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    alpha = datos(:, 1);
    cl = datos(:, 2);
    cd = datos(:, 3);
            
    alpha=[-alpha(end:-1:1);alpha(2:end)];
    cl=[-cl(end:-1:1);cl(2:end)];
    cd=[cd(end:-1:1);cd(2:end)];

        % Crea vectores con NaN
    cl_grado = [datos(1, 4); NaN(size(alpha, 1) - 1, 1)];
    stall = [datos(1, 5); NaN(size(alpha, 1) - 1, 1)];
    cd_grado = [datos(1, 6); NaN(size(alpha, 1) - 1, 1)];

    % Concatena las columnas en una matriz y asigna a la estructura
    Aero.(['RE' num2str(i)]) = [alpha, cl, cd, cl_grado, stall, cd_grado];
end

[p_clalpha, p_cdalpha,ISAVE] = AeroProp;
[CL_real,CD_real]= AerData(p_clalpha,p_cdalpha);

clear datos;
    % Genera el nombre del archivo utilizando sprintf
    nombreArchivo = sprintf('slopes4.txt');

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    mean_slope = datos(:, :);
    
    clear datos;
        % Genera el nombre del archivo utilizando sprintf
    nombreArchivo = sprintf('CLo4.txt');


    %CLo5 tiene 2 pendientes o mas, CLo4 es solo una pendiente

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    CLo = datos(:, :);

%%
Ad = pi*((R_max)^2);                                                        %Disk Area - m^2
d2r = pi/180;                                                               %deg to radians

twistAng=8;                                              

lambda_climb =0;% Vc/(rev*R_max);                                            

solidity=Nb*c_root/(pi*R_max);

for i=1:length(RPM_vec)
    RPM=RPM_vec(i);
    rev = RPM.*(2*pi)/60;     
    Ang=twistAng.*pi/180;

                Ttype=0; Ctype=0; perc=[]; tap=[1.34,0.7619]; percC=[0.3]; slope=[-10.833]*pi/180; param=[ ]; param2=[];

                  solution_matrixNonLine2(i,:)= Hover_Drone2_NoSolve2(Ttype,Ctype,perc,percC,tap,slope,param, param2,Ang,flag);

end

FMnonLin=solution_matrixNonLine2(:,2)./(1.15.*solution_matrixNonLine2(:,2)+solution_matrixNonLine2(:,3));


rev_vec=RPM_vec'.*(2*pi)/60;
figure(5)
hold on
plot(RPM_vec,solution_matrixNonLine2(:,6).*rho.*(pi.*R_max^2).*(rev_vec.*R_max).^2,'*','LineWidth',2)
xlabel('\Omega(rpm)'), ylabel('T(N)')


figure(6)
hold on
plot(RPM_vec,solution_matrixNonLine2(:,7).*rho.*(pi.*R_max^2).*rev_vec.^2.*(R_max).^3,'*','LineWidth',2)
xlabel('\Omega(rpm)'), ylabel('P(w)')

nombres= {'THRUST', 'TORQ', 'TORQu', 'TORQl',};  
for i = 1:length(nombres)
T_exp=0; RPM1=0; P_exp=0; RPM2=0;    
%Genera el nombre del archivo
nombreArchivo = [nombres{i}, '.txt'];
contenido = fileread(nombreArchivo);
    % Reemplaza los tabuladores en blanco con tabuladores regulares
contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
nombreTemporal = 'temp.txt';
fid = fopen(nombreTemporal, 'w');
fwrite(fid, contenidoLimpio);
fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
delete(nombreTemporal);
% 
%     Extrae las columnas en variables separadas
if i==1    

RPM1 = datos(:, 1);
T_exp = datos(:, 2);
figure(5)
plot(RPM1,T_exp,'-','LineWidth',2)
hold on
legend('CLapprox 1 slope','Wind Tunnel','Location','best')
elseif i==2

RPM2 = datos(:, 1);
P_exp = datos(:, 2);
figure(6)
plot(RPM2,P_exp,'go','LineWidth',2)
hold on
legend('CLapprox 1 slope','Wind Tunnel','Location','best')


elseif i==3

RPM3 = datos(:, 1);
P_exp3 = datos(:, 2);
figure(6)
plot(RPM3,P_exp3,'g-','LineWidth',2)
hold on
legend('Mod1','NonLin','Exp','Location','best')
elseif i==4

RPM4 = datos(:, 1);
P_exp4 = datos(:, 2);
figure(6)
plot(RPM4,P_exp4,'g-','LineWidth',2)
hold on
legend('Mod1','NonLin','Exp','Exp Up','Exp Low','Location','best')
end

end


function [p_clalpha, p_cdalpha,ISAVE] = AeroProp
global Aero
% Vector original

enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;

RE_estim=enteros_deseados;
% Redondear al entero más cercano
RE_redondeado = round(RE_estim);

% Lista de enteros deseada
RE=enteros_deseados;
% Ajustar los valores redondeados a los enteros deseados
for i = 1:length(RE_redondeado)
    valor_actual = RE_redondeado(i);
    diferencia = abs(enteros_deseados - valor_actual);
    [~, indice_min] = min(diferencia);
    RE_redondeado(i) = enteros_deseados(indice_min);
end

p_clalpha=0;p_cdalpha=0;

for k=1:length(RE_redondeado)

for i = 1:length(RE)
    condition = (RE_redondeado(k) == RE(i));
    if condition
        p_clalpha(k,1:Aero.(['RE' num2str(i)])(1,4)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,2), Aero.(['RE' num2str(i)])(1,4)).*(RE_redondeado(k)==RE(i));
        p_cdalpha(k,1:Aero.(['RE' num2str(i)])(1,6)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,3), Aero.(['RE' num2str(i)])(1,6)).*(RE_redondeado(k)==RE(i));
        ISAVE(k)=i.*(RE_redondeado(k)==RE(i));
   
    end

end
end



end


function [CL_real,CD_real]= AerData(p_clalpha,p_cdalpha)
global Aero 
 enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;
 alpha_dato=linspace(-20,20,261);

   
                            for n=1:length(enteros_deseados)
                            alpha_datoCD= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+Aero.(['RE' num2str(n)])(1,5).*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato); %to avoid entering in stall
                            alpha_datoCL= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+Aero.(['RE' num2str(n)])(1,5).*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato);                            
                            CL_real(:,n) = polyval(p_clalpha(n,1:Aero.(['RE' num2str(n)])(1,4)+1),alpha_datoCL(:));
                            CD_real(:,n) = polyval(p_cdalpha(n,1:Aero.(['RE' num2str(n)])(1,6)+1),alpha_datoCD(:));

                            end
                          
end 
