% BEM theory for hovering aplicable for large helicopters, using Marco
% Lonoce Airfoils XFOIL data, it computes the required power and the
% collective pitch needed for fulfilling a hovering maneuver for a specific
% helicopter.

%Function Hover computes the required collective pitch among the rest of
%the performance coefficients using the simplified theory and a constant
%slope computed from the polars of marco.

%Function HoverNonLin computes the inflow distribution and the required
%pilot input using the full formulation of BEMT without any simplification
%and considering the real CL and CD in the inflow equation, without
%assuming any kind of possible linearize behaviour or that CL>>CD*phi.
%Small angles are not assumed either.

%Combinations of chord and twist.

%Ctype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables c_root, tap and percC.

%Ctype=0 Straight blade defined by the value of c_tip

%Ctype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param=[tap, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the taper ratio between c_root and c_tip desired and the
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. c_P1 and c_P2 are the
%''chord'' position of those controls points, depending on their value the
%chord will grow more or less (they can be negative but carefully because it can lead to negative chords in the distribution which is unrealistic.)

%Ctype=4 Quadratic chord distribution, c_root and param=[a] shall be provided by the user. a is a value between 0,1  
%if a=0 the distribution will be a straig blade. if a=1 the chord at the
%tip will be 0. Since the apex of the parabola is in the tip, it defines
%the chord at the tip.

%Ttype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables twistAng (which is the collective pitch), slope vector, which contains
% the twist increments of twist in each segment and perc=[rperc1] variable
% with the percentage of the blade for changing the twist rate


%Ttype=0 Untwisted blade with constant pitch defined by the collective that will be computed.

%Ttype=5 Lineal twist, provide slope, which is the differential pitch between tip and chord.

%Ttype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param2=[theta_root, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the pitch at the root, theta_root.
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. theta_P1 and theta_P2 are the
%''pitch'' position of those controls points, depending on their value the
%pitch will grow more or less (it can be either positive or negative but be carefully with providin unrealistic distributions)

%Ttype=6 Quadratic twist distribution, c_root and param=[a] shall be provided by the user  
% Since the apex of the parabola is in the tip, it defines
%the twist at the tip. Collective pitch is computed separetly.
 
%Ttype=4 Ideal twist distribution, it computes the theoretical optimized
%twist of the ideal rotorusing the collective pitch required for providing
%the thrust.


% Tomás Ortiz

%% Acquisition of the informations about the Airfoil

clear all 
close all
clc

global CT_real dr d2r Nb CT_req slope_exp r p_clalpha p_cdalpha R_min R_max c_root c_tip lambda_climb

optimTwist=5 ;
optimChord=0 ;
Spline=0;
Spline2=0;
quad=0;
ideal=0;


 optim=0;
% Open Xfoil file - Read Only

fid = fopen('sc1095_bis.txt', 'r');
for l=1:12
    tline = fgetl(fid);                                                    
end


a = fscanf(fid,'%f', [7 Inf]);                                              
fclose(fid);
                                                                            
                                                                            
clear tline l fid                                                              

%% Characterstics of the Airfoil

alpha = a(1,:);                                                             
CL = a(2,:);                                                                
CD = a(3,:);                                                                

clear a

%% Calculation of Cl_alpha - Linear Regression

x = alpha(35:111)';
y = CL(35:111)';
slope_exp = (x\y)*(180/pi);                                                 %theoretic 2pi - in example naca0012 the number is 6.43

clear x y

%% Interpolation

p_clalpha = polyfit(alpha,CL,10);
p_cdalpha = polyfit(alpha,CD,12);

%% Input Data

n = 260;                                                                    %Number of radial stations to calculate
Nb = 4;                                                                     %Number of blades
c_tip = 0.5273;                                                             %Blade Chord Length - tip - meters
c_root = 0.5273;
RPM = 257.831;                                                              %Rev / Min
W = 8322.4;                                                                 %Mass of the helicopter in kg - needs to be multiplied for 9.807 
R_max = 8.1778;                                                             %Radius in meters
% R_min = 1.39;                                                             %Root cut-off in meters
 R_min = 1.5; 
h = 0;                                                                      %Altitude in meters
Vc = 0;


%% Preliminary Calculations

rho = 1.225*((288-0.0065*h)/288)^4.2561;                                    %Density kg/m^3
rev = RPM*(2*pi)/60;                                                        %Radians per second
dr = (1-R_min/R_max)/n;                                                     %Radial increment - adimensional 
r = ((R_min/R_max):dr:1);                                                   %preallocating the r-range

Ad = pi*((R_max)^2);                                                        %Disk Area - m^2
d2r = pi/180;                                                               %deg to radians

CT_req = (W*9.807)/(rho*Ad*(rev*R_max)^2);                                  %Thrust coefficient requested in hovering for this helicopter


lambda_climb = Vc/(rev*R_max);                                              %Adimensional inflow velocity for climb


%User inputs
Ttype=5; Ctype=0; perc=[]; tap=[]; percC=[]; slope=[-18]*pi/180; param=[ ];  param2=[];
                 
solution_matrix= Hover(Ttype,Ctype,perc,percC,tap,slope,param, param2); %Simplified BEMT  
solution_matrix= HoverNoLin(Ttype,Ctype,perc,percC,tap,slope,param, param2,solution_matrix(1)); %Full BEMT

display(solution_matrix);  

                 
         



