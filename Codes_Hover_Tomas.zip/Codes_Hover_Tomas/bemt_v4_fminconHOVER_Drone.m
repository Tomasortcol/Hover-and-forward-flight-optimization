% BEM theory for hovering aplicable for drones. It computes the collective
% pitch (Even though drones are rigid), it would provide a constant pitch
% required for fulfilling an specific thrust demand in hover flight.

%Function Hover_Drones computes the required collective pitch among the rest of
%the performance coefficients using the simplified theory and a constant
%slope for CL (6.14 typical for NACA 0012) computed from the polars of marco.

%Function HoverNonLin_Drone computes the inflow distribution and the required
%pilot input using the full formulation of BEMT without any simplification
%and considering the real CL and CD in the inflow equation estimated previously with XFOIL for low Re, without
%assuming any kind of possible linearized behaviour or that CL>>CD*phi.
%Small angles are not assumed either.

%Combinations of chord and twist.

%Ctype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables c_root, tap and percC.

%Ctype=0 Straight blade defined by the value of c_tip

%Ctype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param=[tap, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the taper ratio between c_root and c_tip desired and the
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. c_P1 and c_P2 are the
%''chord'' position of those controls points, depending on their value the
%chord will grow more or less (they can be negative but carefully because it can lead to negative chords in the distribution which is unrealistic.)

%Ctype=4 Quadratic chord distribution, c_root and param=[a] shall be provided by the user. a is a value between 0,1  
%if a=0 the distribution will be a straig blade. if a=1 the chord at the
%tip will be 0. Since the apex of the parabola is in the tip, it defines
%the chord at the tip.

%Ttype =1 2-lin segments chord distribution user should modify and select
%the desires values of the variables twistAng (which is the collective pitch), slope vector, which contains
% the twist increments of twist in each segment and perc=[rperc1] variable
% with the percentage of the blade for changing the twist rate


%Ttype=0 Untwisted blade with constant pitch defined by the collective that will be computed.

%Ttype=5 Lineal twist, provide slope, which is the differential pitch between tip and chord.

%Ttype=2 Bézier cubic function for chord. Parameters for user input:
%c_root, and vector param2=[theta_root, r_P1, c_P1, r_P2, c_P2 ], this vector
%should contain the pitch at the root, theta_root.
%coordinates of the control points P1 and P2. r_P1 and r_P2 are values
%between 0 and 0.5 and 0.5 and 1 respectively. theta_P1 and theta_P2 are the
%''pitch'' position of those controls points, depending on their value the
%pitch will grow more or less (it can be either positive or negative but be carefully with providin unrealistic distributions)

%Ttype=6 Quadratic twist distribution, c_root and param=[a] shall be provided by the user  
% Since the apex of the parabola is in the tip, it defines
%the twist at the tip. Collective pitch is computed separetly.
 
%Ttype=4 Ideal twist distribution, it computes the theoretical optimized
%twist of the ideal rotorusing the collective pitch required for providing
%the thrust.


% Tomás Ortiz


%% Acquisition of the informations about the Airfoil

clear all %#ok<CLSCR>
close all
clc

global p CT_real solidity_matrix dr d2r r_matrix phi Ut azimut lambda_PP solidity Nb CT_req CL_real slope_exp r p_clalpha p_cdalpha...
       theta mu R_min R_max c_root c_tip lambda_climb rho muDim nRE inicios_r fin_r Aero rev sub_r%CL CD alpha

optimTwist=5 ;
optimChord=0 ;
Spline=0;
Spline2=0;
quad=0;
ideal=0;


 optim=0;
                                                 

%% Input Data

nRE = 260;                                                                    %Number of radial stations to calculate
Nb = 2;                                                                     %Number of blades
c_tip = 0.02;                                                               %Blade Chord Length - tip - meters
c_root = 0.02;
RPM = 4200;                                                                 %RPM                                                  
W = 0.5;                                                                   %Mass of the helicopter in kg - needs to be multiplied for 9.807 
R_max = 0.2;                                                                  %Radius in meters
 R_min = 0.1.*R_max; 
h = 0;                                                                     %Altitude in meters
Vc = 0;

%% Airfoil

%% Preliminary Calculations

rho = 1.225*((288-0.0065*h)/288)^4.2561;                                          %Density kg/m^3
muDim=1.789*10^(-5);
rev = RPM*(2*pi)/60;                                                        %Radians per second
dr = (1-R_min/R_max)/nRE;                                                     %Radial increment - adimensional 
r = ((R_min/R_max):dr:1);                                                   %preallocating the r-range
slope_exp=6.14;

nRE = 10; % número de subvectores

% Calcula la longitud de cada subvector
longitud_total = numel(r);
longitud_subvector = floor(longitud_total / nRE);

% Inicializa una celda para almacenar los subvectores
subvectores = cell(1, nRE);

% Divide el vector en subvectores de igual longitud
inicio = 1;
% sub_i=zeros(nRE,50);
for i = 1:nRE
    if i <= mod(longitud_total, nRE)
        fin = inicio + longitud_subvector;
    else
        fin = inicio + longitud_subvector - 1;
    end
    sub_r(i,1:fin-inicio+1) = r(inicio:fin);
    inicios_r{i}=inicio;
    fin_r{i}=fin;
    inicio = fin + 1;
end

%% Aero Data
% Define el vector RE con 13 componentes
RE = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200] * 1000;

% Inicializa la estructura Aero
Aero = struct();

% Itera a través de los valores de RE
for i = 1:length(RE)
    % Genera el nombre del archivo utilizando sprintf
    nombreArchivo = sprintf('%d.txt', RE(i));

    % Lee el contenido del archivo
    contenido = fileread(nombreArchivo);

    % Reemplaza los tabuladores en blanco con tabuladores regulares
    contenidoLimpio = regexprep(contenido, '\t+', '\t');

    % Guarda el contenido limpio en un archivo temporal
    nombreTemporal = 'temp.txt';
    fid = fopen(nombreTemporal, 'w');
    fwrite(fid, contenidoLimpio);
    fclose(fid);

    % Lee el archivo temporal con '\t' como delimitador
    datos = importdata(nombreTemporal, '\t');

    % Borra el archivo temporal si es necesario
    delete(nombreTemporal);

    % Extrae las columnas en variables separadas
    alpha = datos(:, 1);
    cl = datos(:, 2);
    cd = datos(:, 3);
            
    alpha=[-alpha(end:-1:1);alpha(2:end)];
    cl=[-cl(end:-1:1);cl(2:end)];
    cd=[cd(end:-1:1);cd(2:end)];

        % Crea vectores con NaN
    cl_grado = [datos(1, 4); NaN(size(alpha, 1) - 1, 1)];
    stall = [datos(1, 5); NaN(size(alpha, 1) - 1, 1)];
    cd_grado = [datos(1, 6); NaN(size(alpha, 1) - 1, 1)];

    % Concatena las columnas en una matriz y asigna a la estructura
    Aero.(['RE' num2str(i)]) = [alpha, cl, cd, cl_grado, stall, cd_grado];
end



Ad = pi*((R_max)^2);                                                        %Disk Area - m^2
d2r = pi/180;                                                               %deg to radians

CT_req = (W*9.807)/(rho*Ad*(rev*R_max)^2);                                  %Thrust coefficient requested in hovering for this helicopter
taper = 1;                                                       %Vector with all the taper ratios --> parametric analysis

lambda_climb = Vc/(rev*R_max);                                              %Adimensional inflow velocity for climb
%% Resolution 
%User's geometry inputs
Ttype=0; Ctype=0; perc=[]; tap=[]; percC=[]; slope=[0]*pi/180; param=[ ];

param2=[];
                 
solution_matrix= Hover_Drone(Ttype,Ctype,perc,percC,tap,slope,param, param2);   
solution_matrixNonLine= HoverNoLin_Drone(Ttype,Ctype,perc,percC,tap,slope,param, param2,solution_matrix(1)); 

display(solution_matrix);  




