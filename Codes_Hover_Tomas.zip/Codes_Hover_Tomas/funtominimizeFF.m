function [app_fmc,solution_matrixNonLine2,solution_matrix2,thetah,alphah,Chord,AER_rat] = funtominimizeFF(x,Ttype,Ctype,theta_col,ini)

 global c_root theta_col rho R_max
            if Ttype==1 && Ctype==0

                theta_col=x(1); slope=x(2:3); perc=x(4); percC=[]; tap=[]; param=[]; param2=[];
  
        elseif Ttype==0 && Ctype==1

                    slope=[0 0]; perc=[]; c_root=x(1); percC=x(4); tap=x(2:3); param=[]; param2=[];
 
        elseif Ttype==1 && Ctype==1
                    
               theta_col=x(1); slope=x(2:3); perc=x(4); c_root=x(5); percC=x(8); tap=x(6:7); param=[]; param2=[];

        elseif Ttype==5 && Ctype==0
                    
                  theta_col=x(1);  slope=x(2); perc=[]; percC=[]; tap=[]; param=[]; param2=[];   

        elseif Ttype==5 && Ctype==3
                    
                  theta_col=x(1);  slope=x(2); perc=[]; c_root=x(3); percC=[]; tap=[x(4)]; param=[]; param2=[];                      

        elseif Ttype==0 && Ctype==3
                    
                    slope=[0 0]; perc=[]; percC=[]; c_root=x(1); tap=[x(2)]; param=[]; param2=[];                         
                
        elseif Ttype==0 && Ctype==2  
                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=x(2:end); param2=[];
                    
        elseif Ttype==1 && Ctype==2

                theta_col=x(1);    slope=x(2:3); perc=x(4); percC=[]; tap=[]; c_root=x(5); param=x(6:10); param2=[];

        elseif Ttype==2 && Ctype==2

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(7); param=x(8:12); param2=x(1:6);

        elseif Ttype==2 && Ctype==1

                    slope=[0 0]; perc=[]; percC=x(10); c_root=x(7); tap=x(8:9); param=[]; param2=x(1:6);
           
        elseif Ttype==2 && Ctype==0

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; param=[]; param2=x(1:6);

        elseif Ttype==6 && Ctype==0

               theta_col=x(1);     slope=[0 0]; perc=[]; percC=[]; tap=[];  param=[ ]; param2=[x(2)];   

        elseif Ttype==0 && Ctype==4

                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=[x(2)]; param2=[];   

        elseif Ttype==6 && Ctype==2

                theta_col=x(1); slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(3); param=x(4:8); param2=x(2);

            end             
                 ini=[];
                 [solution_matrix2(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                 rev=solution_matrix2(1)+100*pi/30;
                 [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag);   
                   
                 app_fmc = (solution_matrix(4)).*rho.*(pi*R_max^2).*(solution_matrix(1)*R_max)^3;

end