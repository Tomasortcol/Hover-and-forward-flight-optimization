function [solution_matrix,thetah,alphah,Chord,AER_rat,lambda]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,x,z,theta_col,ini,flag)

global   CT_req slope_exp r R_min R_max Nb c_root c_tip d2r dr  rho muDim W


                                                           %tollerance in deg for the calculation of the hovering condition CT
iteration = 40;                                                            %number of iteration for the convergence
toll_result = 0.04;
step = 0.20;        
contatore=0;
error_cond=1;

                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + r1*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                       
                            %deg
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));
                            elseif Ctype==3
                            
                            c = c_root + (r-r(1)).*(tap(1) - 1).*c_root./(r(end)-r(1));  
                            elseif Ctype==2

                            P0=[0,c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';

                            elseif Ctype==4
                            
                            c = c_root.(1 + x.*(r-r(1)).^2-2.*x.*(r-r(1)));    

                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 

                            F=1;
                            F2=1;

                            if isempty(ini)
                            ini=5000*pi/30;
                            else

                            ini=ini;
                            end
                            CT_req=(W*9.807)/(rho*pi.*R_max^2*(ini*R_max)^2);  
                            lambda= sqrt(CT_req/2);                            
while (abs(error_cond) > toll_result || step>5) && contatore < iteration 
                            
                            dim_r = size(r);
                            theta_hov = zeros(dim_r(1),dim_r(2));

                       if Ttype==1
                            indices = find(r <= perc(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            theta1 =theta_col +slope(1)*r1; %k2 and theta are in rads
                            theta2=theta_col +slope(1)*r1(end)+slope(2)*(r2-r2(1));


                            theta_hov= [theta1,theta2];
                            %deg
 

                        elseif Ttype==0
 
                            theta_hov=theta_col.*ones(1,length(r)); 

                        elseif Ttype==2
   
                            Pt0=[0,z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

                            Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

                            Points2=Bez2(r'); 
                            Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
                            theta_hov=Ty; %rad 
                            
                       elseif Ttype==4
   
                            theta_hov=theta_col./r; %rad %ideal rotor solution, it is hyperbolic

                       elseif Ttype==5


                            theta_hov =theta_col+slope.*r; %k2 and theta are in rad                            
             

                       elseif Ttype==6


                            theta_hov =theta_col +z(1).*r.^2-2*z(1).*r; %k2 and theta are in rad                            
                            
                        end                       
   
  
                        
                            if contatore>0&&Ttype~=4
                                F(end)=+0.01;  %to avoid dividing by 0 in the expression of Lambda
                            elseif Ttype==4
                                F=1; F2=1;
                            end

                            if contatore>0 && isreal(lambda)==0

                                
                                ini=0.3;
                                F=1; F2=1;
                            end

                            F=F.*ones(1,length(r));


                            % Calculo del RE
                            Vel=@(rev)sqrt((rev*r*R_max).^2+(lambda.*(rev.*R_max)).^2);
%                             inicio=1; fin=length(sub_r{1,1});

                            RE_real=@(rev)rho.*Vel(rev).*c./muDim;
                      

                            
                            lambda = (solidity.*slope_exp)./(16.*F).*(sqrt(1+((32.*F)./(solidity.*slope_exp)).*theta_hov.*r)-1).*(theta_hov>=0)+0.0001.*(theta_hov<0);
                            alpha_real = theta_hov - lambda./r;                               %alpha in radians
                            alpha_real = alpha_real/d2r;                                    %alpha in deg

                            options = optimoptions('fsolve','Display','off','TolX', 1e-6, 'TolFun', 1e-6);
                            [revsol,fval,exitflag]=fsolve(@(rev) eq_solve(rev,alpha_real,r,dr,solidity,F,F2,RE_real),5000*pi/30,options);
                            imagine=imag(revsol);
                            revsol=real(revsol);
                            if Ttype~=4
                            f = (Nb/2)*((1-r)./lambda);
                            F = (2/pi)*acos(exp(-f));
                            f2 = (0.95/2)*((r-R_min/R_max)./lambda);
                            F2 = (2/pi)*acos(exp(-f2));
                            end
                            error_cond = fval/(W*9.807);
                            step=abs(ini-revsol).*30/pi;
                            ini=revsol;
                            
                   

                            contatore = contatore + 1;


end

[~,CL_interpolated,CD_interpolated,CT_real]=eq_solve(revsol,alpha_real,r,dr,solidity,F,F2,RE_real);

               if  (contatore==iteration) || imagine~=0
                   fprintf('Error in the convergence');
                   
               end

                    CP_ind = sum(lambda.*0.5.*solidity.*CL_interpolated.*(r.^2).*dr);

                    %Profile drag

                    CP_profile = sum(0.5*solidity.*CD_interpolated.*(r.^3)*dr);
                    
                    CP_tot = CP_ind + CP_profile;


                    solution_matrix = [revsol CP_ind CP_profile CP_tot CT_real,error_cond,exitflag]
                    thetah=theta_hov*180/pi;
                    alphah=alpha_real;
                    Chord=c;
                    AER_rat=CL_interpolated./CD_interpolated;
                                

% revsol*30/pi
end

function [y,CL_interpolated,CD_interpolated,CT_real]= eq_solve(x,alpha_real,r,dr,solidity,F,F2,RE_real)
global  CL_real CD_real rho R_max W
 enteros_deseados = [0 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;
 alpha_dato=linspace(-20,20,261);

  
                           
                            CL_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CL_real',alpha_real,RE_real(x),'spline');
                            CD_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CD_real',alpha_real,RE_real(x),'spline');

                            CT_real = sum(0.5*solidity.*F2.*CL_interpolated.*(r.^2)*dr);

                            y=CT_real*rho.*(x*R_max)^2*(pi*R_max^2)-W*9.807;

end 
