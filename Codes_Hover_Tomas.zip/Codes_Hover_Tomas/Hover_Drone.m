function [solution_matrix,thetah,alphah,Chord,AER_rat]= Hover_Drone(Ttype,Ctype,perc,percC,tap,slope,x,z)



global   CT_req slope_exp r R_min R_max Nb c_root c_tip d2r dr rho muDim nRE inicios_r fin_r Aero rev 

                                                           %tollerance in deg for the calculation of the hovering condition CT
iteration = 200;                                                            %number of iteration for the convergence
toll_result = 0.01;
step = 0.20;        
contatore=0;
error_cond=1;

                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + r1*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                       
                            %deg
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));

                            elseif Ctype==2

                            P0=[0,c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';

                            elseif Ctype==4
                            
                            c = c_root.(1 + x.*(r-r(1)).^2-2.*x.*(r-r(1)));    

                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 

                            F=1;
                            F2=1;
                            if Ttype~=5
                            k2ini=6*CT_req./(solidity(183).*slope_exp)+3/2*sqrt(CT_req/2);
                            else
                            k2ini=abs(slope).*1.2;
                            end
                            lambda=@(k2) sqrt(CT_req/2);                            
while (abs(error_cond) > toll_result || step>0.01) && contatore < iteration
                            
                            dim_r = size(r);
                            theta_hov = zeros(dim_r(1),dim_r(2));

                       if Ttype==1
                            indices = find(r <= perc(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            theta1 =@(k2) k2 +slope(1)*r1; %k2 and theta are in rads
                            theta2=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2-r2(1));


                            theta_hov=@(k2) [theta1(k2),theta2(k2)];
                            %deg

                        elseif Ttype==0
 
                            theta_hov=@(k2) k2.*ones(1,length(r)); 

                        elseif Ttype==2
   
                            Pt0=[0,z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

                            Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

                            Points2=Bez2(r'); 
                            Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
                            theta_hov=@(k2) Ty+k2; %rad 
                            
                       elseif Ttype==4
   
                            theta_hov=@(k2)k2./r; %rad %ideal rotor solution, it is hyperbolic

                       elseif Ttype==5


                            theta_hov =@(k2) k2 +slope.*r; %k2 and theta are in rad                            
             

                       elseif Ttype==6


                            theta_hov =@(k2) k2 +x(1).*r.^2-2*x(1).*r; %k2 and theta are in rad                            
                            
                        end                       
   
  
                        
                            if contatore>0&&Ttype~=4
                                F(end)=F(end)+10^-6;  %to avoid dividing by 0 in the expression of Lambda
                            elseif Ttype==4
                                F=1; F2=1;
                            end

                            if contatore>0 && isreal(lambda(k2sol))==0

                                
                                k2ini=0.3;
                                F=1; F2=1;
                            end

                            F=F.*ones(1,length(r));


                            % Calculo del RE
                            Vel=sqrt((rev*r*R_max).^2+(lambda(k2ini).*(rev.*R_max)).^2);
%                             inicio=1; fin=length(sub_r{1,1});

                            for n=1:nRE
                            c_RE(n)=mean(c(inicios_r{1,n}:fin_r{1,n}));
                            Vel_avg(n)=mean(Vel(inicios_r{1,n}:fin_r{1,n}));
                            end
                            RE_real=rho.*Vel.*c./muDim;
                            RE_vec=rho.*Vel_avg.*c_RE./muDim;
                            [p_clalpha, p_cdalpha,ISAVE] = AeroProp(RE_vec);
                            
                            lambda = @(k2) ((solidity.*slope_exp)./(16.*F)).*(sqrt(1+((32.*F)./(solidity.*slope_exp)).*theta_hov(k2).*r)-1);
                            alpha_real =@(k2) theta_hov(k2) - lambda(k2)./r;                               %alpha in radians
                            alpha_real =@(k2) alpha_real(k2)/d2r;                                    %alpha in deg


                            ISAVE_vec=zeros(1,length(r));  
                            for n=1:nRE
                            ISAVE_vec(inicios_r{1,n}:fin_r{1,n})=ISAVE(n);
                            STALL_vec(inicios_r{1,n}:fin_r{1,n})=Aero.(['RE' num2str(ISAVE(n))])(1,5);
                            end
                            
                            options = optimoptions('fsolve','Display','off','StepTolerance',1e-16,'MaxFunEvals',1e8,'MaxIter',200);
                                
                            [k2sol,fval,exitflag]=fsolve(@(k2) eq_solve(k2,alpha_real,ISAVE,STALL_vec,r,dr,solidity,F,F2,p_clalpha,p_cdalpha,RE_real,RE_vec),k2ini,options)
                            imagine=imag(k2sol);
                            k2sol=real(k2sol);
                            if Ttype~=4
                            f = (Nb/2)*((1-r)./lambda(k2sol));
                            F = (2/pi)*acos(exp(-f));
                            f2 = (0.95/2)*((r-R_min/R_max)./lambda(k2sol));
                            F2 = (2/pi)*acos(exp(-f2));
                            end

                            error_cond = fval/CT_req;
                            step=abs(k2ini-k2sol)*180/pi;
                            k2ini=k2sol;

                   

                            contatore = contatore + 1;

end

[~,CL_interpolated,CD_interpolated,CT_real]=eq_solve(k2sol,alpha_real,ISAVE,STALL_vec,r,dr,solidity,F,F2,p_clalpha,p_cdalpha,RE_real,RE_vec);

               if  (contatore==iteration) || imagine~=0
                   fprintf('Error in the convergence');
                   
               end

                    CP_ind = sum(lambda(k2sol).*0.5.*solidity.*CL_interpolated.*(r.^2).*dr);

                    %Profile drag

                    CP_profile = sum(0.5*solidity.*CD_interpolated.*(r.^3)*dr);
                   

                    CP_tot = CP_ind + CP_profile;


                    solution_matrix = [k2sol CP_ind CP_profile CP_tot CT_real]
                    thetah=theta_hov(k2sol)*180/pi;
                    alphah=alpha_real(k2sol);
                    Chord=c;
                    AER_rat=CL_interpolated./CD_interpolated;
                                

k2sol*180/pi
end

function [p_clalpha, p_cdalpha,ISAVE] = AeroProp(RE_vec)
global Aero
% Vector original

RE_estim = RE_vec;


enteros_deseados = [0, 10000, 15000, 20000, 30000, 40000, 60000, 80000, 100000, 120000, 140000, 160000, 180000, 200000];

RE_estim=enteros_deseados;
% Redondear al entero más cercano
RE_redondeado = round(RE_estim);

% Lista de enteros deseada
RE=enteros_deseados;
% Ajustar los valores redondeados a los enteros deseados
for i = 1:length(RE_redondeado)
    valor_actual = RE_redondeado(i);
    diferencia = abs(enteros_deseados - valor_actual);
    [~, indice_min] = min(diferencia);
    RE_redondeado(i) = enteros_deseados(indice_min);
end

p_clalpha=0;p_cdalpha=0;

for k=1:length(RE_redondeado)

for i = 1:length(RE)
    condition = (RE_redondeado(k) == RE(i));
    if condition
        p_clalpha(k,1:Aero.(['RE' num2str(i)])(1,4)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,2), Aero.(['RE' num2str(i)])(1,4)).*(RE_redondeado(k)==RE(i));
        p_cdalpha(k,1:Aero.(['RE' num2str(i)])(1,6)+1) =  polyfit(Aero.(['RE' num2str(i)])(:,1), Aero.(['RE' num2str(i)])(:,3), Aero.(['RE' num2str(i)])(1,6)).*(RE_redondeado(k)==RE(i));
        ISAVE(k)=i.*(RE_redondeado(k)==RE(i));
   
    end

end
end



end

function [y,CL_interpolated,CD_interpolated,CT_real]= eq_solve(x,alpha_real,ISAVE,STALL_vec,r,dr,solidity,F,F2,p_clalpha,p_cdalpha,RE_real,RE_vec)
global Aero CT_req
 enteros_deseados = [0, 10000, 15000, 20000, 30000, 40000, 60000, 80000, 100000, 120000, 140000, 160000, 180000, 200000];
 alpha_dato=linspace(-20,20,261);

   
                            for n=1:length(enteros_deseados)
                            alpha_realCD= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+Aero.(['RE' num2str(n)])(1,5).*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato); %to avoid entering in stall
                            alpha_realCL= alpha_dato.*(abs(alpha_dato)<=Aero.(['RE' num2str(n)])(1,5))+5.*(abs(alpha_dato)>Aero.(['RE' num2str(n)])(1,5)).*sign(alpha_dato);                            
                            CL_real(:,n) = polyval(p_clalpha(n,1:Aero.(['RE' num2str(n)])(1,4)+1),alpha_realCL(:));
                            CD_real(:,n) = polyval(p_cdalpha(n,1:Aero.(['RE' num2str(n)])(1,6)+1),alpha_realCD(:));
                            end
                           
                            CL_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CL_real',alpha_real(x),RE_real,'spline');
                            CD_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CD_real',alpha_real(x),RE_real,'spline');

                            CT_real = sum(0.5*solidity.*F2.*CL_interpolated.*(r.^2)*dr);

                            y=CT_real-CT_req;

end 
