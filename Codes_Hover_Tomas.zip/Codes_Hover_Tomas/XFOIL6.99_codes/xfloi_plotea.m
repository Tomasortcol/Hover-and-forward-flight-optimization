%Code for running XFOIL and estimating the polar capacities.
%This code must be in the same folder than XFOIL.exe for being able to run
%it. Also it counts with a txt file with the coordinates of the airfoil
%Eppler 387, NACA database is already implemented in XFOIL

%the parameters oper/iter 1000 is the number of maximum iterations per
%operation.

%ppar/n is the number of divisions of the airfoil geometry, maximum is 240.
%and ppar/t 1 is the density near the leading edge.

close all, 
clear all,
clc

saveFlnmAF = 'Save_Airfoil_E387.txt';
fidAirfoil = fopen(saveFlnmAF);
dataBuffer= textscan(fidAirfoil,'%f %f','CollectOutput',1,'Delimiter','','HeaderLines',0);
fclose(fidAirfoil);
XB= dataBuffer{1}(:,1);
YB=dataBuffer{1}(:,2);
figure(3)
plot(XB,YB,'r');
axis([0 1 -0.06 0.5])

Re=[200000];
CL=[]; CD=[];
alfa=[0:0.1:2];
for i=1:length(Re)

  %select the airfoil 
  %Eppler 387
 [pol,foil] = xfoil([XB,YB],alfa,Re(i),0,'oper/iter 1000','ppar/n 180','ppar/t 1.1','oper/vpar vacc 0.00001') 

  %NACA
%  [pol,foil] = xfoil('Naca0012',alfa,Re(i),0,'oper/iter 500','ppar/n 180','ppar/t 1.1','oper/vpar vacc 0.00001')

   CLE(:,i)=pol.CL; CDE(:,i)=pol.CD;alPH=pol.alpha;
   save('CLE'), save('CDE')
   figure(1); 
   plot(pol.alpha,pol.CL,'LineWidth',2); xlabel('alpha [\circ]'); ylabel('C_L'); title('E387 Re 200k');  
   hold on
   figure(2); 
   plot(pol.alpha(:),pol.CD,'LineWidth',2); xlabel('alpha [\circ]'); ylabel('C_D'); title('E387 Re 200k');  
   hold on
end





