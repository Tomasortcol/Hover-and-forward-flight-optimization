function [solution_matrix,thetah,alphah,Chord,AER_rat,L]= Hover_Drone2_NoSolve2(Ttype,Ctype,perc,percC,tap,slope,x,z,k2ini,flag)
k2sol=k2ini; lambda_ant=[];
CT_real_ant=0.006; dCT_real_ant=0;

global  slope_exp r R_min R_max Nb c_root c_tip d2r dr rho muDim nRE inicios_r fin_r rev 


                                                          
iteration = 200;                                                      
toll_result = 0.04;
step = 0.20;        
contatore=0;
error_cond=1;

                            if Ctype==1
                            indices = find(r <= percC(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            c1 = c_root + r1*(tap(1) - 1)*c_root./(r1(end)-r1(1));                                  %meters
                            c2 = c1(end) + (r2-r2(1))*(tap(2) - 1)*c1(end)./(r2(end)-r2(1));

                            c=[c1,c2];
                       
                            %deg
                            elseif Ctype==0

                            c=c_tip*ones(1,length(r));

                            elseif Ctype==2

                            P0=[0,c_root]; P1=[x(2),x(3)];P2=[x(4),x(5)]; P3=[1,x(1)*c_root];    

                            Bez=@(t)(1-t).^3.*P0+3*(1-t).^2.*t*P1+3*(1-t).*t.^2.*P2+t.^3.*P3;

                            Points=Bez(r'); 
                            cx=Points(:,1); cy=Points(:,2);
                            c=cy';

                            elseif Ctype==4
                            
                            c = c_root.(1 + x.*(r-r(1)).^2-2.*x.*(r-r(1)));    

                            end        
                            solidity = (Nb*c)/(pi*(R_max));                        %Local Solidity in function of the chord 

                            F=1;
                            F2=1;

                            lambda=@(k2) sqrt(CT_real_ant/2);                            
while ( abs(step)>0.02 || step2>0.0001) && contatore < iteration 
                            
                            dim_r = size(r);
                            theta_hov = zeros(dim_r(1),dim_r(2));

                       if Ttype==1
                            indices = find(r <= perc(1));

                            % Partir el vector en dos partes: a y b
                            r1 = r(1:indices(end));
                            r2 = r(indices(end)+1:end);

                            theta1 =@(k2) k2 +slope(1)*r1; %k2 and theta are in rads
                            theta2=@(k2) k2 +slope(1)*r1(end)+slope(2)*(r2-r2(1));


                            theta_hov=@(k2) [theta1(k2),theta2(k2)];
                            %deg

                        elseif Ttype==0
 
                            theta_hov=@(k2) k2.*ones(1,length(r)); 

                        elseif Ttype==2
   
                            Pt0=[0,z(1)]; Pt1=[z(3),z(4)];Pt2=[z(5),z(6)]; Pt3=[1,z(2)];    

                            Bez2=@(t)(1-t).^3.*Pt0+3*(1-t).^2.*t*Pt1+3*(1-t).*t.^2.*Pt2+t.^3.*Pt3;

                            Points2=Bez2(r'); 
                            Tx(1,:)= Points2(:,1); Ty(1,:)=Points2(:,2);
                            theta_hov=@(k2) Ty+k2; %rad 
                            

                       elseif Ttype==5


                            theta_hov =@(k2) k2 +slope.*r; %k2 and theta are in rad                            
             

                       elseif Ttype==6


                            theta_hov =@(k2) k2+x(1).*r.^2-2*x(1).*r; %k2 and theta are in rad                            
                            
                        end                       
   
  
                        
                            if contatore>0&&Ttype~=4
                                F(end)=+0.01;  %to avoid dividing by 0 in the expression of Lambda
                                F2(1)=+0.01;
                            elseif Ttype==4
                                F=1; F2=1;
                            end

                            if contatore>0 && isreal(lambda(k2sol))==0

                                
                                k2ini=0.3;
                                F=1; F2=1;
                            end

                            F=F.*ones(1,length(r));


                            % Calculo del RE
                            Vel=sqrt((rev*r*R_max).^2+(lambda(k2ini).*(rev.*R_max)).^2);
%                             inicio=1; fin=length(sub_r{1,1});

                            for n=1:nRE
                            c_RE(n)=mean(c(inicios_r{1,n}:fin_r{1,n}));
                            Vel_avg(n)=mean(Vel(inicios_r{1,n}:fin_r{1,n}));
                            end
                            RE_real=rho.*Vel.*c./muDim;
                            RE_vec=rho.*Vel_avg.*c_RE./muDim;

                            if contatore==0
                            lambda = @(k2) (solidity.*slope_exp)./(16.*F).*(sqrt(1+((32.*F)./(solidity.*slope_exp)).*theta_hov(k2).*r)-1).*(theta_hov(k2)>=0)+0.0001.*(theta_hov(k2)<0);
                            lambda_ant=lambda(k2ini);
                            else
                                
                            lambda_ant=lambda(k2ini);
                            theta_hov_2=@(k2)theta_hov(k2)+CLo_exp_vec./slope_exp_vec;
                            lambda = @(k2) (solidity.*slope_exp_vec)./(16.*F).*(sqrt(1+((32.*F)./(solidity.*slope_exp_vec)).*theta_hov_2(k2).*r)-1).*(theta_hov_2(k2)>=0)+0.0001.*(theta_hov_2(k2)<0);
                            end
                            %URF (entre 0 y 1)
                            relax = 0.7; 

                            % Relaxed Inflow distribution
                            L_prima = relax * lambda_ant + (1 - relax) * lambda(k2sol);

                            alpha_real =@(k2) theta_hov(k2) - atan(L_prima./r);                               %alpha in radians
                            alpha_real =@(k2) alpha_real(k2)/d2r;                                    %alpha in deg

                            [~,CL_interpolated,CD_interpolated,CT_real,dCT_real,dCT_real2,slope_exp_vec,CLo_exp_vec,CT_real2]=eq_solve(k2ini,alpha_real,r,dr,solidity,F,F2,RE_real,L_prima);
                            if Ttype~=4
                            f = (Nb/2)*((1-r)./L_prima);
                            F = (2/pi)*acos(exp(-f));
                            f2 = (0.95/2)*((r-R_min/R_max)./L_prima);
                            F2 = (2/pi)*acos(exp(-f2));
                            end
                            step2=rms(dCT_real-dCT_real_ant);
                            step=(CT_real-CT_real_ant)/CT_real_ant;
                            dCT_real_ant=dCT_real;
                            CT_real_ant=CT_real;
                            
       
                            
                   

                            contatore = contatore + 1;


end
k2sol=k2ini;

PenaltyCont=0;
 [~,CL_interpolated,CD_interpolated,CT_real,dCT_real,dCT_real2,slope_exp_vec,CLo_exp_vec,CT_real2]=eq_solve(k2ini,alpha_real,r,dr,solidity,F,F2,RE_real,L_prima);
               if  (contatore==iteration) 
                    fprintf('Error in the convergence')                   
               end

                    CP_ind = sum(L_prima.*0.5.*solidity.*CL_interpolated.*(r.^2).*dr);
                    CP_ind2 = sum(L_prima.*0.5.*solidity.*(slope_exp_vec.*(alpha_real(k2sol)).*pi./180+CLo_exp_vec).*(r.^2).*dr);
                    %Profile drag

                    CP_profile = sum(0.5*solidity.*CD_interpolated.*(r.^3)*dr);
                    

                    %Drag

                    CP_tot = CP_ind + CP_profile;
                    CP_tot2 = CP_ind2+ CP_profile;


                    % riempimento matrice soluzione

                    solution_matrix = [k2sol CP_ind CP_profile CP_tot CT_real,CT_real2,CP_tot2];
                    thetah=theta_hov(k2sol)*180/pi;
                    alphah=alpha_real(k2sol);
                    Chord=c;
                    AER_rat=CL_interpolated./CD_interpolated;
                    L=lambda(k2sol);
                                

k2sol*180/pi;
end

function [y,CL_interpolated,CD_interpolated,CT_real,dCT_real,dCT_real2,slope_exp_vec,CLo_exp_vec,CT_real2]= eq_solve(x,alpha_real,r,dr,solidity,F,F2,RE_real,lambda)
global  CL_real CD_real mean_slope CLo
 enteros_deseados = [0, 10, 15, 20, 30, 40, 60, 80, 100, 120, 140 160 180 200 250 300 350 400 450 500 600 700 800 900 1000 2000 3000 4000 5000 6000] * 1000;
 alpha_dato=linspace(-20,20,261);alpha_dato2=linspace(-20,20,length(mean_slope(:,1)));
  
%                            
                            alfa=alpha_real(x);
                            alfa=[alfa(1:end-1),alfa(end-1)];

                            CL_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CL_real',alfa,RE_real);
                            CD_interpolated = interp2(ones(length(enteros_deseados),1)*alpha_dato,enteros_deseados'*ones(1,261),CD_real',alfa,RE_real);                            
                            slope_exp_vec = interp2(ones(length(enteros_deseados),1)*alpha_dato2,enteros_deseados'*ones(1,length(mean_slope(:,1))),mean_slope',alfa,RE_real);
                            CLo_exp_vec = interp2(ones(length(enteros_deseados),1)*alpha_dato2,enteros_deseados'*ones(1,length(mean_slope(:,1))),CLo',alfa,RE_real);
                          

%                          

                            dCT_real= 0.5*solidity.*F2.*(CL_interpolated).*(r.^2);  
                            dCT_real2= 0.5*solidity.*F2.*(slope_exp_vec.*(alpha_real(x)).*pi./180+CLo_exp_vec).*(r.^2);  
                            CT_real = sum(dCT_real.*dr);
                            CT_real2 = sum(dCT_real2.*dr);

                            y=0;

end 
