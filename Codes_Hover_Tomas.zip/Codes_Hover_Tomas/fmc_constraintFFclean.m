function [c,ceq] = fmc_constraintFFclean(x,Ttype,Ctype,theta_col,ini)
global theta_col r
ceq=[0];
            if Ttype==1 && Ctype==0

               theta_col=x(1); slope=x(2:3); perc=x(4); percC=[]; tap=[]; param=[]; param2=[];
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    
                    twist_pos=x(1)-abs(x(2));
                    twist_pos2=x(1)-abs(x(2))-abs(x(3));

                     c = [-CP_ind,-twist_pos,-twist_pos2];   

         elseif Ttype==5 && Ctype==0

                    theta_col=x(1);  slope=x(2); perc=[]; percC=[]; tap=[]; param=[]; param2=[]; 
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                                   
                    twist_pos=x(1)-abs(x(2));


                     c = [-CP_ind,-twist_pos];   
         elseif Ttype==5 && Ctype==3

                    theta_col=x(1);  slope=x(2); perc=[]; percC=[]; c_root=x(3); tap=[x(4)]; param=[]; param2=[]; 
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                  
                    twist_pos=x(1)-abs(x(2));


                     c = [-CP_ind,-twist_pos];                        

        elseif Ttype==0 && Ctype==3
                    
                    slope=[0 0]; perc=[]; percC=[]; c_root=x(1); tap=[x(2)]; param=[]; param2=[];
                
                     [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);              
                     c = [-CP_ind];                    
  
        elseif Ttype==0 && Ctype==1

                   slope=[0 0]; perc=[]; c_root=x(1); percC=x(4); tap=x(2:3); param=[]; param2=[];
                     [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    c = [-CP_ind];   
 
        elseif Ttype==1 && Ctype==1
                    
                    theta_col=x(1); slope=x(2:3); perc=x(4); c_root=x(5); percC=x(8); tap=x(6:7); param=[]; param2=[];
                
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);            
                    twist_pos=x(1)-abs(x(2));
                    twist_pos2=x(1)-abs(x(2))-abs(x(3));

                     c = [-CP_ind,-twist_pos,-twist_pos2];   

        elseif Ttype==1 && Ctype==2
                    
                   theta_col=x(1);    slope=x(2:3); perc=x(4); percC=[]; tap=[]; c_root=x(5); param=x(6:10); param2=[];
                
                       [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    twist_pos=x(1)-abs(x(2));
                    twist_pos2=x(1)-abs(x(2))-abs(x(3));

                     c = [-CP_ind,-twist_pos,-twist_pos2];   
        elseif Ttype==0 && Ctype==2
                    slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=x(2:end); param2=[];
                       [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    
                     c = [-CP_ind];   

        elseif Ttype==2 && Ctype==0
                    
                    slope=[0 0]; perc=[]; param=[]; tap=[];  percC=[]; param2=x;
                
                   [solution_matrix2(:),thetah]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    twist_pos=sum(thetah<0);
                    ceq=[twist_pos];
                    
                     c = [-CP_ind,-twist_pos];   

        elseif Ttype==2 && Ctype==1
                    
                     slope=[0 0]; perc=[]; percC=x(10); c_root=x(7); tap=x(8:9); param=[]; param2=x(1:6);
                
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    
                     c = [-CP_ind];                  

        elseif Ttype==2 && Ctype==2
                    
                   slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(7); param=x(8:12); param2=x(1:6);
                
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    
                     c = [-CP_ind];    
        elseif Ttype==6 && Ctype==0

                    theta_col=x(1); slope=[0 0]; perc=[]; percC=[]; tap=[];  param=[ ]; param2=[x(2)];  
                     [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    twist_pos=x(1)-x(2);
                    
                    c = [-CP_ind,-twist_pos];   

        elseif Ttype==0 && Ctype==4

                   slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(1); param=[x(2)]; param2=[];        
                   [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    
                    c = [-CP_ind];        

        elseif Ttype==6 && Ctype==2

                theta_col=x(1); slope=[0 0]; perc=[]; percC=[]; tap=[]; c_root=x(3); param=x(4:8); param2=x(2);                    
                       [solution_matrix2(:)]= Hover_Drone2_RPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,ini);   
                   rev=solution_matrix2(1)+100*pi/30;
                   [solution_matrix(:),thetah,alphah,Chord,AER_rat]= Hover_Drone2_LinSolveRPM(Ttype,Ctype,perc,percC,tap,slope,param, param2,theta_col,rev,flag); 

                    CP_ind = solution_matrix(2);
                    twist_pos=x(1)-x(2);
                    
                    c = [-CP_ind,-twist_pos]; 

            end


end


